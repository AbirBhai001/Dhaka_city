package com.mission.dhakacity; // আপনার প্যাকেজের নাম ব্যবহার করুন

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final List<Message> messageList;

    public MessageAdapter(List<Message> messageList) {
        this.messageList = messageList;
    }

    @Override
    public int getItemViewType(int position) {
        // বার্তার প্রেরকের ধরণের উপর ভিত্তি করে View Type নির্ধারণ করা
        return messageList.get(position).getSender();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        if (viewType == Message.SENDER_USER) {
            // ব্যবহারকারীর বার্তার জন্য লেআউট (ডানদিকে)
            view = inflater.inflate(R.layout.item_message, parent, false);
            return new UserMessageViewHolder(view);
        } else {
            // বটের বার্তার জন্য লেআউট (বামদিকে)
            view = inflater.inflate(R.layout.item_message, parent, false);
            return new BotMessageViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Message message = messageList.get(position);

        if (holder.getItemViewType() == Message.SENDER_USER) {
            // ব্যবহারকারীর বার্তা হলে
            UserMessageViewHolder userHolder = (UserMessageViewHolder) holder;
            userHolder.textViewUserMessage.setText(message.getText());
            userHolder.textViewUserMessage.setVisibility(View.VISIBLE);
            userHolder.textViewBotMessage.setVisibility(View.GONE); // বট টেক্সট হাইড করা
        } else {
            // বটের বার্তা হলে
            BotMessageViewHolder botHolder = (BotMessageViewHolder) holder;
            botHolder.textViewBotMessage.setText(message.getText());
            botHolder.textViewBotMessage.setVisibility(View.VISIBLE);
            botHolder.textViewUserMessage.setVisibility(View.GONE); // ইউজার টেক্সট হাইড করা
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    // ব্যবহারকারীর বার্তার জন্য ViewHolder
    public static class UserMessageViewHolder extends RecyclerView.ViewHolder {
        TextView textViewUserMessage;
        TextView textViewBotMessage; // ViewHolder এক হলেও আমরা কেবল একটি TextView ব্যবহার করব

        public UserMessageViewHolder(View itemView) {
            super(itemView);
            textViewUserMessage = itemView.findViewById(R.id.textViewUserMessage);
            textViewBotMessage = itemView.findViewById(R.id.textViewBotMessage);
        }
    }

    // বটের বার্তার জন্য ViewHolder
    public static class BotMessageViewHolder extends RecyclerView.ViewHolder {
        TextView textViewBotMessage;
        TextView textViewUserMessage; // ViewHolder এক হলেও আমরা কেবল একটি TextView ব্যবহার করব

        public BotMessageViewHolder(View itemView) {
            super(itemView);
            textViewBotMessage = itemView.findViewById(R.id.textViewBotMessage);
            textViewUserMessage = itemView.findViewById(R.id.textViewUserMessage);
        }
    }
}