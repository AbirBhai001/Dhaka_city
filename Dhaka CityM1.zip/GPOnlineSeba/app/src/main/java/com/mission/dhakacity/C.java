package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;

public class C extends AppCompatActivity {


    LinearLayout shareapp, moreapp, fapage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_about_layout);

        shareapp = findViewById(R.id.shareapp);
        moreapp = findViewById(R.id.moreapp);
        fapage = findViewById(R.id.fapage);





        shareapp.setOnClickListener(v ->{
            //code here======
            shareapp(C.this);


        });


        moreapp.setOnClickListener(v -> {
            //code here===
            String developerName ="Bongo DigiTech";
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=pub:" + developerName )));
            }catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" +developerName )));

            }

        });



        fapage.setOnClickListener(v -> {
            //code here===
            String id ="100088533430700";
            //developerName = ("100088533430700");
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("fb.//page/:" + id )));
            }catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/share/1DKwSPwdV2/?mibextid=wwXIfr" )));

            }

        });




    }//Oncreate mathot colose here======



    //============
    private void shareapp(Context context){
        //code hrere===
        final String appPakageName = context.getPackageName();
        Intent sendIntent = new Intent();
        sendIntent.setAction(Intent.ACTION_SEND);
        sendIntent.putExtra(Intent.EXTRA_TEXT, "Download Now : https://play.google.com/store/apps/details?id=" + appPakageName);
        sendIntent.setType("text/plain");
        context.startActivity(sendIntent);
    }




}//Publice class close here==========