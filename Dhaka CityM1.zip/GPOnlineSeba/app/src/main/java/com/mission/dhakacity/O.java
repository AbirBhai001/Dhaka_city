package com.mission.dhakacity;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class O extends AppCompatActivity implements J.GeminiCallback {

    private List<Message> messageList;
    private MessageAdapter messageAdapter;
    private RecyclerView recyclerView;
    private EditText editTextMessage;
    private ImageButton buttonSend;
    private J apiService;
    private Handler handler = new Handler();

    // বটের টাইপিং ইন্ডিকেটর এর জন্য ডামি মেসেজ
    private static final String TYPING_INDICATOR = "বট টাইপিং করছে...";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // activity_main.xml ফাইলটিকে সেট করা
        setContentView(R.layout.activity_main_ai);

        // ভিউ উপাদানগুলির রেফারেন্স পাওয়া
        recyclerView = findViewById(R.id.recyclerView);
        editTextMessage = findViewById(R.id.editTextMessage);
        buttonSend = findViewById(R.id.buttonSend);

        // পরিষেবা ইনিশিয়ালাইজ করা
        apiService = new J();

        // বার্তা তালিকা এবং অ্যাডাপ্টার সেটআপ করা
        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        // নতুন বার্তা সবসময় নিচে দেখানোর জন্য
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(messageAdapter);

        // অ্যাপ শুরু হলে স্বাগত বার্তা যোগ করা
        addBotMessage("স্বাগতম! আমি আপনার নিজস্ব এআই সহকারী। আমি সাধারণ প্রশ্নের পাশাপাশি আপনার দৈনন্দিন জীবনের দুঃসময় ট্রেকিং করে সহায়তা করার চেষ্টা করতে পারি!এ কাজের জন্য নিয়োজিত করেছেন ~Al Sadat Mission & Abir Islam Shuvo");

        // সেন্ড বাটনে ক্লিক লিসেনার সেট করা
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    // বার্তা পাঠানোর ফাংশন
    private void sendMessage() {
        final String userMessage = editTextMessage.getText().toString().trim();

        if (userMessage.isEmpty()) {
            Toast.makeText(this, "কিছু একটা লিখুন", Toast.LENGTH_SHORT).show();
            return;
        }

        // ১. ব্যবহারকারীর বার্তা যোগ করা
        addUserMessage(userMessage);

        // ২. EditText খালি করা
        editTextMessage.setText("");

        // ৩. হাইব্রিড লজিক প্রয়োগ করা
        handler.post(new Runnable() {
            @Override
            public void run() {
                String localResponse = getLocalResponse(userMessage);

                if (localResponse != null) {
                    // যদি স্থানীয় উত্তর পাওয়া যায়, তবে দ্রুত সেটা দেখানো হবে
                    addBotMessage(localResponse);
                } else {
                    // যদি না মেলে, তবে জেমিনিকে কল করা হবে
                    callGeminiForResponse(userMessage);
                }
            }
        });
    }

    // ###############################################################
    // হাইব্রিড লজিক: স্থানীয় বা হার্ডকোডেড উত্তর প্রদান
    // ###############################################################
    private String getLocalResponse(String userMessage) {
        String lowerCaseMessage = userMessage.toLowerCase(Locale.ROOT).trim();

        if (lowerCaseMessage.contains("অ্যাপ তৈরি করেছে") || lowerCaseMessage.contains("কে বানালো")) {
            return "এই অ্যাপটির ভিত্তি তৈরি করেছে ~AL Sadat Mission & Abir Islam Shuvo,-এর একটি ভাষা মডেল।";
        } else if (lowerCaseMessage.contains("ভার্সন কত") || lowerCaseMessage.contains("সংস্করণ")) {
            return "বর্তমান অ্যাপের ভার্সন,v1.0 কোড এবং Mahfuj API ব্যবহার করছে- অ্যাপের সঙ্গে নিয়মিত আপডেট থাকুন";
        } else if (lowerCaseMessage.contains("এই অ্যাপসটির নাম কি?") || lowerCaseMessage.contains("এর পরিচিতি নাম বলো?")) {
            return "Dhaka City App এই অ্যাপসটির  নির্মাতা ~Al Sadat Mission";
        } else if (lowerCaseMessage.contains("হেল্প লাইন") || lowerCaseMessage.contains("ফোন নম্বর")) {
            return "আমি একটি ভার্চুয়াল সহকারী, আমার কোনো হেল্প লাইন বা ফোন নম্বর নেই।";
        }

        // কোনো হার্ডকোডেড উত্তর না পেলে null ফেরত দেওয়া হবে, যাতে জেমিনি কল হয়
        return null;
    }

    // জেমিনি API কল করার লজিক
    private void callGeminiForResponse(String userMessage) {
        // বাটন ডিজেবল করা
        setUiEnabled(false);

        // বটের টাইপিং ইন্ডিকেটর যোগ করা
        addBotMessage(TYPING_INDICATOR);

        // জেমিনি API কল করা
        apiService.getResponseAsync(userMessage, this);
    }
    // ###############################################################


    // ব্যবহারকারীকে বার্তা যোগ করার জন্য
    private void addUserMessage(String text) {
        messageList.add(new Message(text, Message.SENDER_USER));
        messageAdapter.notifyItemInserted(messageList.size() - 1);
        recyclerView.scrollToPosition(messageList.size() - 1);
    }

    // বটকে বার্তা যোগ করার জন্য
    private void addBotMessage(String text) {
        messageList.add(new Message(text, Message.SENDER_BOT));
        messageAdapter.notifyItemInserted(messageList.size() - 1);
        recyclerView.scrollToPosition(messageList.size() - 1);
    }

    // সর্বশেষ বার্তার (টাইপিং ইন্ডিকেটর) আপডেট করার জন্য
    private void updateLastBotMessage(String newText) {
        int lastIndex = messageList.size() - 1;
        // আমরা শুধু নিশ্চিত করছি যে শেষ বার্তাটি টাইপিং ইন্ডিকেটর কি না
        if (lastIndex >= 0 && messageList.get(lastIndex).getText().equals(TYPING_INDICATOR)) {
            messageList.remove(lastIndex); // ডামি ইন্ডিকেটর সরিয়ে দাও
            messageList.add(new Message(newText, Message.SENDER_BOT)); // আসল বার্তা যোগ করো
            messageAdapter.notifyItemChanged(lastIndex);
        } else {
            // যদি কোনো কারণে ইন্ডিকেটর না থাকে, তবে নতুন বার্তা হিসেবে যোগ করো
            addBotMessage(newText);
        }
        recyclerView.scrollToPosition(messageList.size() - 1);
    }

    // ইনপুট UI নিয়ন্ত্রণ করার জন্য
    private void setUiEnabled(boolean enabled) {
        editTextMessage.setEnabled(enabled);
        buttonSend.setEnabled(enabled);
        if (enabled) {
            buttonSend.setAlpha(1.0f);
        } else {
            buttonSend.setAlpha(0.5f); // ডিজেবল হলে হালকা করে দেখানো
        }
    }

    // #####################################################################
    // GeminiCallback ইন্টারফেসের ইমপ্লিমেন্টেশন (API উত্তর পাওয়ার পরে)
    // #####################################################################

    @Override
    public void onResponse(final String response) {
        // UI থ্রেডে ফলাফল আপডেট করা
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateLastBotMessage(response);
                setUiEnabled(true);
            }
        });
    }

    @Override
    public void onFailure(final String error) {
        // UI থ্রেডে ত্রুটি বার্তা দেখানো
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateLastBotMessage("ত্রুটি: " + error);
                setUiEnabled(true);
            }
        });
    }
}