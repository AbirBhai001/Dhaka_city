package com.mission.dhakacity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class W extends AppCompatActivity {

    private Switch switchSecurity;
    private TextView tvSecurityStatus, tvEarthquakeStatus;
    private ProgressBar earthquakeGraph;
    private Button btnTestEarthquake;
    private RecyclerView recyclerEarthquakes;
    private boolean isSecurityOn = false;

    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "SafetyAppPrefs";
    private static final String KEY_SECURITY_MODE = "security_mode";

    // থ্রেশহোল্ড নয়, আমরা এখন সেনসিটিভিটি (0-100) সেভ করবো
    private static final String KEY_SOUND_SENSITIVITY = "sound_sensitivity";
    private static final String KEY_SHAKE_SENSITIVITY = "shake_sensitivity";
    private static final String KEY_CONTACT_NUMBER_1 = "contact_number_1";
    private static final String KEY_CONTACT_NUMBER_2 = "contact_number_2";

    // ডিফল্ট সেনসিটিভিটি (0-100 এর মধ্যে)
    // 0 = খুব কম সংবেদনশীল (জোরে শব্দ লাগবে)
    // 100 = খুব বেশি সংবেদনশীল (আস্তে শব্দেই বাজবে)
    private static final int DEFAULT_SENSITIVITY = 50;

    private LocationManager locationManager;
    private static final int ALL_PERMISSION_CODE = 101;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable earthquakeRunnable;
    private Ringtone testRingtone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sefty);

        switchSecurity = findViewById(R.id.switchSecurity);
        tvSecurityStatus = findViewById(R.id.tvSecurityStatus);
        tvEarthquakeStatus = findViewById(R.id.tvEarthquakeStatus);
        earthquakeGraph = findViewById(R.id.earthquakeGraph);
        btnTestEarthquake = findViewById(R.id.btnTestEarthquake);
        recyclerEarthquakes = findViewById(R.id.recyclerEarthquakes);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        checkPermissions();
        setupEarthquakeList();

        isSecurityOn = sharedPreferences.getBoolean(KEY_SECURITY_MODE, false);
        switchSecurity.setChecked(isSecurityOn);
        updateSecurityStatus(isSecurityOn);

        if (getIntent().getBooleanExtra("TRIGGER_ALERT", false)) {
            String reason = getIntent().getStringExtra("ALERT_REASON");
            showSecurityDialog(reason != null ? reason : "সতর্কতা!");
        }

        switchSecurity.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isSecurityOn = isChecked;
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(KEY_SECURITY_MODE, isSecurityOn);
            editor.apply();
            updateSecurityStatus(isSecurityOn);

            if (isChecked) {
                showSensitivityDialog();
            } else {
                stopSafetyService();
                Toast.makeText(W.this, "নিরাপত্তা মোড বন্ধ হয়েছে", Toast.LENGTH_SHORT).show();
            }
        });

        startEarthquakeSimulation();
        btnTestEarthquake.setOnClickListener(v -> getLocationAndShowAlert());
    }

    private void showSensitivityDialog() {
        // সেভ করা সেনসিটিভিটি লোড করা (0 থেকে 100)
        int currentSoundSens = sharedPreferences.getInt(KEY_SOUND_SENSITIVITY, DEFAULT_SENSITIVITY);
        int currentShakeSens = sharedPreferences.getInt(KEY_SHAKE_SENSITIVITY, DEFAULT_SENSITIVITY);

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_sensitivity_settings, null);

        TextView tvSoundLabel = dialogView.findViewById(R.id.tvSoundLabel);
        SeekBar sbSound = dialogView.findViewById(R.id.sbSound);
        TextView tvShakeLabel = dialogView.findViewById(R.id.tvShakeLabel);
        SeekBar sbShake = dialogView.findViewById(R.id.sbShake);
        EditText etContact1 = dialogView.findViewById(R.id.etContact1);
        EditText etContact2 = dialogView.findViewById(R.id.etContact2);

        etContact1.setText(sharedPreferences.getString(KEY_CONTACT_NUMBER_1, ""));
        etContact2.setText(sharedPreferences.getString(KEY_CONTACT_NUMBER_2, ""));

        // শব্দ সেটিংস (0-100)
        sbSound.setMax(100);
        sbSound.setProgress(currentSoundSens);
        updateSoundLabel(tvSoundLabel, currentSoundSens);

        sbSound.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSoundLabel(tvSoundLabel, progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // ঝাঁকুনি সেটিংস (0-100)
        sbShake.setMax(100);
        sbShake.setProgress(currentShakeSens);
        updateShakeLabel(tvShakeLabel, currentShakeSens);

        sbShake.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateShakeLabel(tvShakeLabel, progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        new AlertDialog.Builder(this)
                .setTitle("নিরাপত্তা কনফিগারেশন")
                .setView(dialogView)
                .setCancelable(false)
                .setPositiveButton("চালু করুন", (dialog, which) -> {
                    int finalSoundSens = sbSound.getProgress();
                    int finalShakeSens = sbShake.getProgress();
                    String num1 = etContact1.getText().toString();
                    String num2 = etContact2.getText().toString();

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putInt(KEY_SOUND_SENSITIVITY, finalSoundSens);
                    editor.putInt(KEY_SHAKE_SENSITIVITY, finalShakeSens);
                    editor.putString(KEY_CONTACT_NUMBER_1, num1);
                    editor.putString(KEY_CONTACT_NUMBER_2, num2);
                    editor.apply();

                    checkPermissionsAndStartService(finalSoundSens, finalShakeSens);
                })
                .setNegativeButton("বাতিল", (dialog, which) -> {
                    switchSecurity.setChecked(false);
                    isSecurityOn = false;
                    updateSecurityStatus(false);
                })
                .show();
    }

    // ইউজারকে বোঝানোর জন্য লেবেল আপডেট
    private void updateSoundLabel(TextView view, int progress) {
        String desc;
        if (progress < 30) desc = "(শুধু চিৎকার শুনবে)";
        else if (progress < 70) desc = "(মাঝারি শব্দ)";
        else desc = "(সামান্য শব্দেই বাজবে)";
        view.setText("শব্দ শনাক্তকরণ মাত্রা: " + progress + "% " + desc);
    }

    private void updateShakeLabel(TextView view, int progress) {
        String desc;
        if (progress < 30) desc = "(শুধু আছাড়/ধাক্কা)";
        else if (progress < 70) desc = "(মাঝারি ঝাঁকুনি)";
        else desc = "(সামান্য নড়লেই বাজবে)";
        view.setText("কম্পন শনাক্তকরণ মাত্রা: " + progress + "% " + desc);
    }

    private void checkPermissionsAndStartService(int soundSens, int shakeSens) {
        List<String> neededPermissions = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) neededPermissions.add(Manifest.permission.RECORD_AUDIO);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) neededPermissions.add(Manifest.permission.SEND_SMS);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) neededPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION);

        if (!neededPermissions.isEmpty()) {
            ActivityCompat.requestPermissions(this, neededPermissions.toArray(new String[0]), ALL_PERMISSION_CODE);
            switchSecurity.setChecked(false);
            Toast.makeText(this, "অনুগ্রহ করে সব পারমিশন দিন", Toast.LENGTH_SHORT).show();
        } else {
            startSafetyService(soundSens, shakeSens);
            Toast.makeText(W.this, "নিরাপত্তা চালু হয়েছে (SMS সক্রিয়)", Toast.LENGTH_LONG).show();
        }
    }

    private void startSafetyService(int soundSens, int shakeSens) {
        Intent serviceIntent = new Intent(this, T.class);
        // সেনসিটিভিটি পাস করা হচ্ছে (0-100)
        serviceIntent.putExtra(KEY_SOUND_SENSITIVITY, soundSens);
        serviceIntent.putExtra(KEY_SHAKE_SENSITIVITY, shakeSens);
        serviceIntent.putExtra(KEY_CONTACT_NUMBER_1, sharedPreferences.getString(KEY_CONTACT_NUMBER_1, ""));
        serviceIntent.putExtra(KEY_CONTACT_NUMBER_2, sharedPreferences.getString(KEY_CONTACT_NUMBER_2, ""));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }

    private void startSafetyService() {
        int soundSens = sharedPreferences.getInt(KEY_SOUND_SENSITIVITY, DEFAULT_SENSITIVITY);
        int shakeSens = sharedPreferences.getInt(KEY_SHAKE_SENSITIVITY, DEFAULT_SENSITIVITY);
        startSafetyService(soundSens, shakeSens);
    }

    private void stopSafetyService() {
        Intent serviceIntent = new Intent(this, T.class);
        stopService(serviceIntent);
    }

    private void checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS, Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION}, ALL_PERMISSION_CODE);
        }
    }

    private void updateSecurityStatus(boolean isOn) {
        if (isOn) {
            tvSecurityStatus.setText("অবস্থা: চালু (অটোমেটিক SMS)");
            tvSecurityStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
        } else {
            tvSecurityStatus.setText("অবস্থা: বন্ধ");
            tvSecurityStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra("TRIGGER_ALERT", false)) {
            String reason = intent.getStringExtra("ALERT_REASON");
            showSecurityDialog(reason != null ? reason : "সতর্কতা!");
        }
    }

    private void showSecurityDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("সতর্কতা! নিরাপত্তা লঙ্ঘন!")
                .setMessage(message + "\nস্বয়ংক্রিয়ভাবে SMS এবং লোকেশন পাঠানো হয়েছে।")
                .setCancelable(false)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton("আমি নিরাপদ (বন্ধ করুন)", (dialog, which) -> {
                    stopSafetyService();
                    if (isSecurityOn) {
                        startSafetyService(); // আগের সেটিংসে আবার চালু
                    }
                })
                .show();
    }

    // --- ভূমিকম্প ট্র্যাকিং (সমন্বয় করা হয়েছে) ---
    private void startEarthquakeSimulation() {
        earthquakeRunnable = new Runnable() {
            @Override
            public void run() {
                int randomLevel = new Random().nextInt(100);
                earthquakeGraph.setProgress(randomLevel);
                // ম্যাগনিটিউড সিমুলেশন (1.0 থেকে 9.9)
                double simulatedMagnitude = 1.0 + (randomLevel / 100.0) * 8.9;
                String statusText = "অবস্থা: ";

                // কালার কনস্ট্যান্টস
                final int COLOR_GREEN = 0xFF4CAF50;   // সবুজ
                final int COLOR_ORANGE = 0xFFFF9800;  // কমলা/বাদামি
                final int COLOR_RED = 0xFFD32F2F;     // গাড়ো লাল

                // প্রোগ্রেস ও টেক্সট কালার পরিবর্তন
                if (randomLevel < 40) { // Magnitude < ~4.56
                    earthquakeGraph.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_GREEN));
                    tvEarthquakeStatus.setTextColor(COLOR_GREEN); // টেক্সট কালার সবুজ
                    statusText += "স্বাভাবিক";
                } else if (randomLevel < 70) { // Magnitude ~4.56 to ~7.13
                    earthquakeGraph.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_ORANGE));
                    tvEarthquakeStatus.setTextColor(COLOR_ORANGE); // টেক্সট কালার কমলা/বাদামি
                    statusText += "মৃদু কম্পন";
                } else { // Magnitude > ~7.13
                    earthquakeGraph.setProgressTintList(android.content.res.ColorStateList.valueOf(COLOR_RED));
                    tvEarthquakeStatus.setTextColor(COLOR_RED); // টেক্সট কালার গাড়ো লাল
                    statusText += "বিপদজনক";
                }
                tvEarthquakeStatus.setText(statusText + " (" + String.format(Locale.getDefault(), "%.1f", simulatedMagnitude) + ")");
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(earthquakeRunnable);
    }

    private void setupEarthquakeList() {
        recyclerEarthquakes.setLayoutManager(new LinearLayoutManager(this));
        List<EarthquakeModel> earthquakeList = new ArrayList<>();
        earthquakeList.add(new EarthquakeModel("রাশিয়া, কামচাটকা পেনিনসুলা", "8.8", "প্রায় ২৭০ সেকেন্ড", "২৯ জুলাই ২০২৫, রাত ২৩:২৪ UTC (স্থানীয়: ৩০ জুলাই ২০২৫, সকাল ১১:২৪ PETT"));
        earthquakeList.add(new EarthquakeModel("মায়ানমার, মাণ্ডালے (Sagaing/Mandalay এপিকেন্টার)", "7.7", "প্রায় ৬০–৯০ সেকেন্ড (approx.)", "২৮ মার্চ ২০২৫, দুপুর ~১২:৫০ MMT"));
        earthquakeList.add(new EarthquakeModel("ফিলিপাইন, মানায় (দক্ষিণ মিন্দানাও / Davao Oriental)", "7.4", "প্রায় ৬০–৯০ সেকেন্ড (approx.)", "১০ অক্টোবর ২০২৫, সকাল ০৯:৪৩ PHT"));
        earthquakeList.add(new EarthquakeModel("ইউএসএ, আলাস্কা (Sand Point অঞ্চল)", "7.3", "প্রায় ৬০ সেকেন্ড", "১৬ জুলাই ২০২৫, দুপুর ~১২:৩৭ (Alaska Time)"));
        earthquakeList.add(new EarthquakeModel("দক্ষিণ আটলান্টিক / Drake Passage (Aug 22)", "7.5", "প্রায় ৪০–৮০ সেকেন্ড (approx.)", "২২ আগস্ট ২০২৫ (UTC-সময় দেখুন উৎস)"));
        earthquakeList.add(new EarthquakeModel("দক্ষিণ আটলান্টিক / Drake Passage (May 2)", "7.4", "প্রায় ৪০–৭০ সেকেন্ড (approx.)", "২ মে ২০২৫ (UTC-সময় দেখুন উৎস)"));
        earthquakeList.add(new EarthquakeModel("ফিলিপাইন, সেবু (Bogo / সহরাঞ্চল)", "6.9", "প্রায় ৩০ সেকেন্ড", "৩০ সেপ্টেম্বর ২০২৫, রাত ২১:৫৯ PHT"));
        earthquakeList.add(new EarthquakeModel("পাপুয়া নিউ গিনি, Angoram অঞ্চল", "6.5", "প্রায় ৩০–৪৫ সেকেন্ড (approx.)", "২০ মে ২০২৫, (UTC/স্থানীয় সময় দেখুন উৎস)"));
        earthquakeList.add(new EarthquakeModel("জাপান, ইওয়াতে (Far-E off Yamada)", "6.8", "প্রায় ২৫–৪৫ সেকেন্ড", "৯ নভেম্বর ২০২৫, সকাল (UTC→স্থানীয় JST conversion আছে উৎসে)"));
        earthquakeList.add(new EarthquakeModel("আফগানিস্তান, Khulm / Mazār-e-Sharīf নিকট", "6.3", "প্রায় ২০–৩০ সেকেন্ড", "২ নভেম্বর ২০২৫, রাত ০০:৫৯ AFT (স্থানীয়)"));
        earthquakeList.add(new EarthquakeModel("পেরু, Callao (লিমা উপকূল)", "5.6", "~২০ সেকেন্ড (approx.)", "১৫ জুন ২০২৫, স্থানীয় ~১১:৩৫ PET"));
        earthquakeList.add(new EarthquakeModel("দক্ষিণ আটলান্টিক / Drake Passage (Oct 10 event)", "7.6", "প্রায় ৪০–৭০ সেকেন্ড (approx.)", "১০ অক্টোবর ২০২৫ (UTC-ও স্থানীয় টাইম ভিত্তিক)"));
        earthquakeList.add(new EarthquakeModel("চিলি, Diego de Almagro (উত্তর/কেন্দ্রীয়)", "6.4", "প্রায় ৩০ সেকেন্ড", "৬ জুন ২০২৫, বিকাল ~১৩:১৫ (স্থানীয়)"));
        earthquakeList.add(new EarthquakeModel("চিলি, Calama অঞ্চলে (Tarapacá/Antofagasta সীমান্ত)", "6.0", "প্রায় ২০–৩০ সেকেন্ড", "২ জানুয়ারি ২০২৫, স্থানীয় ~২০:৪৩ UTC→CLT conversion"));
        earthquakeList.add(new EarthquakeModel("ইন্দোনেশিয়া, Papua (Abepura/উত্তর উপকূল নিকট)", "6.5", "প্রায় ৩০–৪৫ সেকেন্ড", "১৬ অক্টোবর ২০২৫, স্থানীয় ~১৪:৪৮ WIT"));
        earthquakeList.add(new EarthquakeModel("পাপুয়া নিউ গিনি, Lorengau নিকট", "6.3", "প্রায় ৩০ সেকেন্ড", "১০ অক্টোবর ২০২৫ (UTC/স্থানীয় সময় উৎসে দেখুন)"));
        earthquakeList.add(new EarthquakeModel("বাংলাদেশ, নরসিংদী (Ghorashal/Narsingdi এলাকা)", "5.5", "৫–৬ সেকেন্ড (ঘরোয়া ক্ষুদ্র তীব্রতা)", "২১ নভেম্বর ২০২৫, সকাল ১০:৩৮ (স্থানীয় সময়)"));
        earthquakeList.add(new EarthquakeModel("ইন্দোনেশিয়া, উত্তর-পূর্ব জাভা (30 Sep event)", "6.0", "প্রায় ২০–৩০ সেকেন্ড", "৩০ সেপ্টেম্বর ২০২৫ (স্থানীয় সময় উৎসে দেখুন)"));
        earthquakeList.add(new EarthquakeModel("Southern East Pacific Rise (সমুদ্রমধ্য)", "6.0", "প্রায় ১৫–৩০ সেকেন্ড", "৫ মে ২০২৫ (UTC-সময়; উৎস দেখুন)"));
        earthquakeList.add(new EarthquakeModel("চিলি, Tarapacá-Antofagasta সীমান্ত (৬.১ Jan 2)", "6.1", "প্রায় ১৫–২৫ সেকেন্ড", "২ জানুয়ারি ২০২৫, স্থানীয় সময় ~২০:৪৩ UTC"));
        earthquakeList.add(new EarthquakeModel("বাংলাদেশ, নরসিংদী", "5.5", "৫-৬ সেকেন্ড", "২১ নভেম্বর ২০২৫, সকাল ১০:৩৮ "));
        EarthquakeAdapter adapter = new EarthquakeAdapter(earthquakeList);
        recyclerEarthquakes.setAdapter(adapter);
    }

    private void getLocationAndShowAlert() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, ALL_PERMISSION_CODE);
            return;
        }
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            String addressString = "লোকেশন পাওয়া যাচ্ছে না (GPS অন করুন)";
            if (location != null) {
                Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    addressString = address.getLocality() != null ? address.getLocality() : address.getAddressLine(0);
                    if(address.getAdminArea() != null) addressString += ", " + address.getAdminArea();
                } else {
                    addressString = String.format(Locale.getDefault(), "Lat: %.4f, Lon: %.4f", location.getLatitude(), location.getLongitude());
                }
            }
            triggerEarthquakeAlert(addressString, calculateFutureTime());
        } catch (Exception e) {
            e.printStackTrace();
            triggerEarthquakeAlert("লোকেশন লোড ব্যর্থ", calculateFutureTime());
        }
    }

    private String calculateFutureTime() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.HOUR_OF_DAY, 3 + new Random().nextInt(21));
        return new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(calendar.getTime());
    }

    private void triggerEarthquakeAlert(String location, String time) {
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (notification == null) notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            testRingtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
            testRingtone.play();
        } catch (Exception e) { e.printStackTrace(); }

        String message = "আপনার বর্তমান অবস্থান: " + location + "\n\n" +
                "আর্টিফিশিয়াল ইন্টেলিজেন্স বিশ্লেষণ:\n" +
                "এই অঞ্চলে টেকটোনিক প্লেট স্বাভাবিক। সতর্কতার জন্য সম্ভাব্য ঝুঁকির সময়: " + time + "।\n\n" +
                "ভয় পাবেন না, এটি সিমুলেশন।";

        new AlertDialog.Builder(this)
                .setTitle("⚠️ আধুনিক ভূমিকম্প বিশ্লেষণ")
                .setMessage(message)
                .setCancelable(false)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton("নিরাপদ আছি", (dialog, which) -> {
                    if (testRingtone != null && testRingtone.isPlaying()) testRingtone.stop();
                })
                .show();
    }

    public static class EarthquakeModel {
        String location, magnitude, duration, date;
        public EarthquakeModel(String location, String magnitude, String duration, String date) {
            this.location = location;
            this.magnitude = magnitude;
            this.duration = duration;
            this.date = date;
        }
    }

    public class EarthquakeAdapter extends RecyclerView.Adapter<EarthquakeAdapter.ViewHolder> {
        List<EarthquakeModel> list;
        public EarthquakeAdapter(List<EarthquakeModel> list) { this.list = list; }
        @NonNull @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_earthquake, parent, false);
            return new ViewHolder(view);
        }
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            EarthquakeModel model = list.get(position);
            holder.tvLocation.setText(model.location);
            holder.tvMagnitude.setText(model.magnitude);
            holder.tvDuration.setText("স্থায়ী: " + model.duration);
            holder.tvDate.setText("সময়: " + model.date);
        }
        @Override
        public int getItemCount() { return list.size(); }
        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvLocation, tvMagnitude, tvDuration, tvDate;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvLocation = itemView.findViewById(R.id.tvLocation);
                tvMagnitude = itemView.findViewById(R.id.tvMagnitude);
                tvDuration = itemView.findViewById(R.id.tvDuration);
                tvDate = itemView.findViewById(R.id.tvDate);
            }
        }
    }
}