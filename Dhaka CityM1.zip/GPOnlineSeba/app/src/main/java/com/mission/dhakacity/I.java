package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class I extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gd_mamla_layout);
    }
}