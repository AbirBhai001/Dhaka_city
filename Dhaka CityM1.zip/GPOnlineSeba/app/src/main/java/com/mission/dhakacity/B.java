package com.mission.dhakacity;


import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.cardview.widget.CardView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;
import org.osmdroid.views.overlay.compass.CompassOverlay;
import org.osmdroid.views.overlay.gestures.RotationGestureOverlay;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class B extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS_REQUEST_CODE = 1;
    private MapView map;
    private MyLocationNewOverlay myLocationOverlay;
    private GeoPoint liveLocation;
    private EditText searchEditText;
    private Button searchButton;
    private CardView infoPanel;
    private TextView placeCountText, establishmentCountText, phoneNumberText;
    private List<GeoPoint> searchResults = new ArrayList<>();
    private List<Marker> resultMarkers = new ArrayList<>();
    private Polyline routeOverlay = null;

    // API URL for Nominatim (OSM Geocoding for search)
    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/search?format=json&q=";
    // API URL for OSRM (Open Source Routing Machine for directions)
    private static final String OSRM_URL = "https://router.project-osrm.org/route/v1/driving/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // OSMDroid কনফিগারেশন সেটআপ
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));
        setContentView(R.layout.activity_map);

        // UI উপাদানগুলি খুঁজুন
        searchEditText = findViewById(R.id.edit_text_search);
        searchButton = findViewById(R.id.button_search);
        map = findViewById(R.id.map_view);
        infoPanel = findViewById(R.id.info_panel);
        placeCountText = findViewById(R.id.text_place_count);
        establishmentCountText = findViewById(R.id.text_establishment_count);
        phoneNumberText = findViewById(R.id.text_phone_number);

        // প্রয়োজনীয় অনুমতিগুলি (Permissions) চাইতে হবে
        requestPermissionsIfNecessary(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.WRITE_EXTERNAL_STORAGE // OSMDroid এর ক্যাশের জন্য
        });

        // ম্যাপ সেটআপ
        setupMap();

        // সার্চ বাটনে ক্লিক লিসেনার
        searchButton.setOnClickListener(v -> {
            String query = searchEditText.getText().toString();
            if (!query.isEmpty()) {
                searchLocation(query);
            } else {
                Toast.makeText(this, "অনুগ্রহ করে স্থান বা প্রতিষ্ঠানের নাম লিখুন।", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupMap() {
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true); // জুম, প্যান, ইত্যাদি নিয়ন্ত্রণ সক্ষম করুন

        // কম্পাস যোগ করুন
        map.getOverlays().add(new CompassOverlay(this, map));
        // রোটেশন অঙ্গভঙ্গি যোগ করুন
        map.getOverlays().add(new RotationGestureOverlay(map));

        // আমার অবস্থান ওভারলে যোগ করুন
        GpsMyLocationProvider locationProvider = new GpsMyLocationProvider(this);
        myLocationOverlay = new MyLocationNewOverlay(locationProvider, map);
        myLocationOverlay.enableMyLocation();
        map.getOverlays().add(myLocationOverlay);

        // **সমস্যা সমাধান:** runOnFirstFix একটি ব্যাকগ্রাউন্ড থ্রেড থেকে কল হতে পারে, তাই UI আপডেট (zoom, animateTo)
        // অবশ্যই Main UI Thread-এ চালাতে হবে।
        myLocationOverlay.runOnFirstFix(() -> {
            // runOnUiThread ব্যবহার করে UI থ্রেডে স্যুইচ করা হয়েছে
            runOnUiThread(() -> {
                liveLocation = myLocationOverlay.getMyLocation();
                if (liveLocation != null) {
                    IMapController mapController = map.getController();
                    mapController.setZoom(15.0);
                    mapController.animateTo(liveLocation);
                }
            });
        });

        // ডিফল্ট সেন্টার পয়েন্ট (যদি অবস্থান না পাওয়া যায়)
        IMapController mapController = map.getController();
        mapController.setZoom(12.0);
        mapController.setCenter(new GeoPoint(23.777176, 90.399452)); // ঢাকা, বাংলাদেশ
    }

    /**
     * Error Fix: BoundingBox তৈরি করার জন্য ম্যানুয়াল ফাংশন।
     * এই পদ্ধতিটি OSMDroid ভার্সনের উপর নির্ভরতা এড়ায়।
     */
    private BoundingBox calculateBoundingBox(List<GeoPoint> points) {
        if (points == null || points.isEmpty()) {
            // যদি কোন পয়েন্ট না থাকে, ডিফল্ট বাউন্ডিং বক্স ফেরত দিন
            return new BoundingBox(90.0, 180.0, -90.0, -180.0);
        }

        double minLat = Double.MAX_VALUE;
        double maxLat = Double.MIN_VALUE;
        double minLon = Double.MAX_VALUE;
        double maxLon = Double.MIN_VALUE;

        for (GeoPoint p : points) {
            minLat = Math.min(minLat, p.getLatitude());
            maxLat = Math.max(maxLat, p.getLatitude());
            minLon = Math.min(minLon, p.getLongitude());
            maxLon = Math.max(maxLon, p.getLongitude());
        }

        // BoundingBox constructor is (North, East, South, West)
        return new BoundingBox(maxLat, maxLon, minLat, minLon);
    }

    private void searchLocation(String query) {
        // পূর্ববর্তী মার্কার এবং রুট মুছে ফেলুন
        map.getOverlays().removeAll(resultMarkers);
        resultMarkers.clear();
        searchResults.clear();
        if (routeOverlay != null) {
            map.getOverlays().remove(routeOverlay);
            routeOverlay = null;
        }
        infoPanel.setVisibility(View.GONE);
        map.invalidate();

        // AsyncTask ব্যবহার করে নেটওয়ার্ক অপারেশন সম্পাদন করুন
        new NominatimSearchTask().execute(query);
    }

    private void drawRoute(GeoPoint startPoint, GeoPoint endPoint) {
        if (routeOverlay != null) {
            map.getOverlays().remove(routeOverlay);
        }
        new OSRMRoutingTask().execute(startPoint, endPoint);
    }

    private void showRouteAndMarkers(List<GeoPoint> points, String query) {
        searchResults.clear();
        searchResults.addAll(points);

        if (points.isEmpty()) {
            Toast.makeText(this, query + " এর জন্য কোনো স্থান খুঁজে পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
            return;
        }

        // লাইভ লোকেশন নিশ্চিত করুন
        if (liveLocation == null) {
            Toast.makeText(this, "আপনার লাইভ লোকেশন খুঁজে পাওয়া যায়নি।", Toast.LENGTH_LONG).show();

            // যদি লাইভ লোকেশন না পাওয়া যায়, তবে getLastKnownLocation দিয়ে চেষ্টা করুন
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Location lastLocation = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (lastLocation != null) {
                    liveLocation = new GeoPoint(lastLocation.getLatitude(), lastLocation.getLongitude());
                } else {
                    // map.getCenter() এরর ফিক্স করা হয়েছে: map.getMapCenter() ব্যবহার করা হয়েছে
                    liveLocation = (GeoPoint) map.getMapCenter();
                }
            } else {
                liveLocation = (GeoPoint) map.getMapCenter();
            }
        }

        // প্রথম স্থানটির জন্য দিকনির্দেশ আঁকুন (ডিরেকশন)
        drawRoute(liveLocation, points.get(0));

        // সমস্ত মার্কার এবং লাইভ লোকেশন ধারণ করার জন্য একটি তালিকা
        List<GeoPoint> allPointsForZoom = new ArrayList<>(points);
        allPointsForZoom.add(liveLocation);

        // সকল স্থানকে মার্কার হিসেবে দেখান
        for (int i = 0; i < points.size(); i++) {
            GeoPoint point = points.get(i);
            Marker marker = new Marker(map);
            marker.setPosition(point);
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);

            // মার্কারগুলির চেহারা এবং তথ্য সেট করা
            if (i == 0) {
                marker.setTitle(query + " (প্রধান গন্তব্য)");
                // ডিফল্ট মার্কার ব্যবহার করা হচ্ছে
                updateInfoPanel(points.size(), points.size(), "N/A (API দ্বারা সমর্থিত নয়)");
            } else {
                // বিকল্প গন্তব্যগুলির জন্য ডিফল্ট মার্কার, সাথে সিরিয়াল নম্বর
                marker.setTitle("বিকল্প গন্তব্য " + (i + 1));
                marker.setSnippet("এখানে ক্লিক করলে দিকনির্দেশ দেখাবে।");
            }

            // মার্কার ক্লিক লিসেনার সেট করুন
            int finalI = i;
            marker.setOnMarkerClickListener((m, mapView) -> {
                // বিকল্প মার্কারগুলিতে ক্লিক করলে নতুন রুট আঁকা হবে
                if (finalI > 0) {
                    drawRoute(liveLocation, m.getPosition());
                    Toast.makeText(B.this, "গন্তব্য " + (finalI + 1) + " এর দিকে দিকনির্দেশ আপডেট করা হয়েছে।", Toast.LENGTH_SHORT).show();
                }
                return false; // ডিফল্ট আচরণ বজায় রাখতে
            });

            map.getOverlays().add(marker);
            resultMarkers.add(marker);
        }

        // BoundingBox লজিক
        if (allPointsForZoom.size() > 1) {
            BoundingBox bounds = calculateBoundingBox(allPointsForZoom);
            map.zoomToBoundingBox(bounds, true, 50);
        } else if (allPointsForZoom.size() == 1) {
            // যদি শুধুমাত্র একটি বিন্দু থাকে (লাইভ লোকেশন), তাহলে ম্যাপটিকে সেখানে নিয়ে যান
            IMapController mapController = map.getController();
            mapController.setZoom(15.0);
            mapController.animateTo(allPointsForZoom.get(0));
        }

        map.invalidate();
    }

    private void updateInfoPanel(int totalPlaces, int establishments, String phoneNumber) {
        placeCountText.setText(String.format("১. একই নামে স্থান সংখ্যা: %d টি", totalPlaces));
        establishmentCountText.setText(String.format("২. প্রতিষ্ঠান সংখ্যা: %d টি", establishments));
        phoneNumberText.setText(String.format("৩. প্রতিষ্ঠান নাম্বার: %s", phoneNumber.isEmpty() ? "N/A (API দ্বারা সমর্থিত নয়)" : phoneNumber));
        infoPanel.setVisibility(View.VISIBLE);
    }

    // Nominatim (সার্চ) এর জন্য AsyncTask
    private class NominatimSearchTask extends AsyncTask<String, Void, List<GeoPoint>> {
        private String query;

        @Override
        protected List<GeoPoint> doInBackground(String... params) {
            query = params[0];
            OkHttpClient client = new OkHttpClient();
            String url = NOMINATIM_URL + query;
            List<GeoPoint> points = new ArrayList<>();

            try {
                Request request = new Request.Builder()
                        .url(url)
                        .header("User-Agent", "OSMMultiDirectionApp/1.0") // User-Agent আবশ্যক
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String json = response.body().string();
                    JSONArray jsonArray = new JSONArray(json);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);
                        double lat = obj.getDouble("lat");
                        double lon = obj.getDouble("lon");
                        points.add(new GeoPoint(lat, lon));
                        if (points.size() >= 5) break; // সর্বাধিক 5টি ফলাফল যথেষ্ট
                    }
                }
            } catch (Exception e) {
                Log.e("NominatimSearchTask", "Search Error: " + e.getMessage());
            }
            return points;
        }

        @Override
        protected void onPostExecute(List<GeoPoint> points) {
            showRouteAndMarkers(points, query);
        }
    }

    // OSRM (ডিরেকশন) এর জন্য AsyncTask
    private class OSRMRoutingTask extends AsyncTask<GeoPoint, Void, List<GeoPoint>> {

        @Override
        protected List<GeoPoint> doInBackground(GeoPoint... points) {
            if (points.length < 2) return null;
            GeoPoint start = points[0];
            GeoPoint end = points[1];

            OkHttpClient client = new OkHttpClient();
            // OSRM রুট ফরম্যাট: lon1,lat1;lon2,lat2
            String url = OSRM_URL + start.getLongitude() + "," + start.getLatitude() + ";"
                    + end.getLongitude() + "," + end.getLatitude() + "?overview=full&geometries=geojson";
            List<GeoPoint> routePoints = new ArrayList<>();

            try {
                Request request = new Request.Builder()
                        .url(url)
                        .build();

                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String json = response.body().string();
                    JSONObject jsonResponse = new JSONObject(json);
                    JSONArray routes = jsonResponse.getJSONArray("routes");
                    if (routes.length() > 0) {
                        JSONObject route = routes.getJSONObject(0);
                        JSONObject geometry = route.getJSONObject("geometry");
                        JSONArray coordinates = geometry.getJSONArray("coordinates");

                        for (int i = 0; i < coordinates.length(); i++) {
                            JSONArray coord = coordinates.getJSONArray(i);
                            double lon = coord.getDouble(0);
                            double lat = coord.getDouble(1);
                            routePoints.add(new GeoPoint(lat, lon));
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("OSRMRoutingTask", "Routing Error: " + e.getMessage());
            }
            return routePoints;
        }

        @Override
        protected void onPostExecute(List<GeoPoint> routePoints) {
            if (routePoints != null && !routePoints.isEmpty()) {
                if (routeOverlay != null) {
                    map.getOverlays().remove(routeOverlay);
                }
                routeOverlay = new Polyline();
                routeOverlay.setPoints(routePoints);
                routeOverlay.setColor(Color.BLUE); // ডিরেকশন লাইন নীল রঙের
                routeOverlay.setWidth(10.0f);
                map.getOverlays().add(routeOverlay);
                map.invalidate();
            } else {
                Toast.makeText(B.this, "দিকনির্দেশ রুট খুঁজে পাওয়া যায়নি।", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // --- পার্মিশন হ্যান্ডলিং ---
    private void requestPermissionsIfNecessary(String[] permissions) {
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(permission);
            }
        }
        if (!permissionsToRequest.isEmpty()) {
            ActivityCompat.requestPermissions(
                    this,
                    permissionsToRequest.toArray(new String[0]),
                    REQUEST_PERMISSIONS_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        ArrayList<String> permissionsToRequest = new ArrayList<>();
        for (int i = 0; i < grantResults.length; i++) {
            permissionsToRequest.add(permissions[i]);
        }
        if (permissionsToRequest.size() > 0) {
            // যদি অনুমতি না দেওয়া হয়, ব্যবহারকারীকে অবস্থান চালু করতে অনুরোধ করুন
            Toast.makeText(this, "ম্যাপ ও অবস্থান ব্যবহারের জন্য অনুমতি প্রয়োজন।", Toast.LENGTH_LONG).show();
        }
    }

    // --- লাইফসাইকেল মেথড: ম্যাপ বন্ধ এবং চালু করা ---
    @Override
    protected void onResume() {
        super.onResume();
        map.onResume(); // ম্যাপ ভিউ রিফ্রেশ
        // Check if myLocationOverlay is initialized before enabling
        if (myLocationOverlay != null) {
            myLocationOverlay.enableMyLocation(); // অবস্থান ট্র্যাকিং পুনরায় শুরু
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        map.onPause(); // ম্যাপ ভিউ পজ
        // Check if myLocationOverlay is initialized before disabling
        if (myLocationOverlay != null) {
            myLocationOverlay.disableMyLocation(); // অবস্থান ট্র্যাকিং বন্ধ
        }
    }
}