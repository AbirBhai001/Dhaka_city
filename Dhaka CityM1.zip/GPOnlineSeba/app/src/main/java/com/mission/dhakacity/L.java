package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import java.util.ArrayList;
import java.util.HashMap;

public class L extends AppCompatActivity {

    //initaliz variable
    ListView hotelListView;
    TextView title;
    //initaliz arrayList
    HashMap<String,String>hashMap=new HashMap<>();
    public static ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>hotelList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>hospitalList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>curearlList=new ArrayList<>();

    public static String TITLE="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);

        hotelListView=findViewById(R.id.hotelLIstView);
        title=findViewById(R.id.title);







        //=============crete curearlList

        createCurearlList("সুন্দরবন কুরিয়ার সার্ভিস পটুয়খালী","Byamagar more, ঢাকা","01758689522");
        createCurearlList("USB কুরিয়ার সার্ভিস পটুয়খালী","Nehal uddin Market, boro chowrasta","01701-208198");
        createCurearlList("সুন্দরবন কুরিয়ার সার্ভিস গলাচিপা","গলাচিপা থানার সামনে","01725-274350");
        createCurearlList("সুন্দরবন কুরিয়ার সার্ভিস কলাপাড়া","কলেজ রোড কলাপাড়া","01778-100065");
        createCurearlList("আমতলী সুন্দরবন কুরিয়ার সার্ভিস"," Amtoli,Barguna Kuriar kahagat ","01788-699500");
        createCurearlList("মির্জাগঞ্জ সুন্দরবন কুরিয়ার সার্ভিস","মির্জাগঞ্জ","01716819115");
        createCurearlList("বরগুনা সুন্দরবন কুরিয়ার সার্ভিস","বরগুনা","01936006575");
        curearlList=new ArrayList<>();
        //============================



        //Create Hospital List************************************
        createHospitalList("সেন্টাল হসপিটাল","ঢাকা","01780285562");
        createHospitalList("প্রাইম ক্লিনিক এন্ড ডায়াগনস্টিক সেন্টার","পুরাতন ফেরিঘাট রোড, ঢাকা।","01715131516");
        createHospitalList("ইসলামিয়া হসপিটাল এন্ড ডায়াগনস্টিক সেন্টার","পুরাতন ফেরিঘাট রোড, ঢাকা","01312134585");
        createHospitalList("ঢাকা ডায়বেটিস সেন্টার","ঢাকা","01720474934");
        createHospitalList("বি.এন.এস.বি চক্ষু হাসপাতাল, ঢাকা","গরিব,অসহায়, দু:স্থ চক্ষু রোগিদের জন্য ফ্রি ","01752014939");
        createHospitalList(" এস.এইচ.এস.বি স্পেশালাইজড","চৌরাস্তা ,ঢাকা","01730279414");
        createHospitalList("গ্রিন ভিউ হসপিটাল","কাজী বাড়ি রোড, ঢাকা 8600","01709455556");

        createHospitalList("নোভা ডায়াগনোষ্টিক সেন্টার","থানা পাড়া রোড,ঢাকা","০৪৪১-৬৩৩৪১");
        createHospitalList("হিমি পলি ক্লিনিক","সার্কিট হাউজ রোড,ঢাকা","০৪৪১-৬২৮৮৮");
        createHospitalList("হেলথ কেয়ার ক্লিনিক","শেরে বাংলা সড়ক,ঢাকা","০১৭১২২৮২৮৪৪");
        createHospitalList("ঢাকা ক্লিনিক","২১,কাজী পাড়া,ঢাকা","০৪৪১-৬২৩২১");
        createHospitalList("মুক্তি ক্লিনিক","পিটিআইরোড,ঢাকা","০৪৪১-৬৩১৯৮");
        createHospitalList("ফরচুন  হাসপাতাল","শেরে বাংলা সড়ক,ঢাকা","০১৭১৬২২৩১৯১");
        createHospitalList("নুর জেনারেল হাসপাতাল","পুলিশ লাইন রোড়,কলাতলা ঢাকা","০১৭১২৫২২৬৩০");
        createHospitalList("হেলথ কেয়ার ডায়াগনোষ্টিকসেন্টার","শেরে বাংলা সড়ক,ঢাকা","০৪৪১-৬৩৮০৮");
        createHospitalList("ঢাকা প্যাথলজী সেন্টার","২১,কাজী পাড়া,ঢাকা","০৪৪১-৬২৩২১");
        createHospitalList("আব্দুল্লাহ ডায়াগনোষ্টিক সেন্টার","নবাব পাড়া,ঢাকা","০৪৪১-৬৪৪৫৩");
        createHospitalList("ফরচুন ডায়াগনোষ্টিক সেন্টার ","শেরে বাংলা সড়ক,ঢাকা","০১৭১৬২২৩১৯১");
        createHospitalList("নুর জেনারেল হাসপাতাল প্যাথ সে:","পুলিশ লাইন রোড়,কলাতলা,","০১৭১২৫২২৬৩০");
        createHospitalList("ট্যু-প্যাথলজী সেন্টার","মহিলা কলেজ রোড,ঢাকা","০৪৪১-৬২০৬০");
        createHospitalList("প্রাইম ডায়াগনোষ্টিক সেন্টার","জে:হাস:রোড,ঢাকা","০১৭১৫১৩১৫১৬");
        createHospitalList("হাট ফাউডডিশন (ডায়া) ক্লিনিক","মুন্সেফপাড়া রোড,ঢাকা","০১৭৩৭৯০৭০৫৩");
        createHospitalList("সেবা ডায়াগনোষ্টিক সেন্টার","পিটিআই রোড,ঢাকা","০১৭১৪২৩৪৪৬৪");
        createHospitalList("আমেনা ডায়াগনোষ্টিক সেন্টার","পাওয়ার হাউজ রোড,ঢাকা","০১৭১২৬৫৯৮০৮");
        createHospitalList("মর্ডান কম্পিউটারজডডায়া সেন্টার","গলাচিপা বন্দর,ঢাকা","০১৭১৫০৫০৯৮৭");
        hospitalList=new ArrayList<>();
        //****************************************************


        //Create L List*********************************
        crateHotelList("ভোজন বাড়ী রেস্টুরেন্ট","টাউন কালিকাপুর, বর চৌরাস্তা-ঢাকা।","01790243388");
        crateHotelList("স্টার রেস্তোরা সুইটমিট","টাউন কালিকাপুর, বর চৌরাস্তা-ঢাকা।","01732661144");
        crateHotelList("মল্লিকা রেস্টুরেন্ট","পুরাতন জেলখানা রোড, ঢাকা।","01727-139393");
        crateHotelList("হোটেল হিলটন","সদর রোড, ঢাকা।","01722228777");
        crateHotelList("ফুড-কিং","কাজী বাড়ি রোড, ঢাকা","01623503884");
        crateHotelList("পায়রা হোটেল","1 সদর রোড, ঢাকা","01710532443");

        crateHotelList("হোটেল পায়রা","সদর রোড, ঢাকা।","01710-532443");
        crateHotelList("হোটেল পানামা ইন্টারন্যাসনাল"," রোড, ঢাকা।","01789-803706");
        crateHotelList("জোনাকি হোটেল"," , ঢাকা।","01724-768783");
        crateHotelList("হোটেল রুপশী বাংলা"," , ঢাকা।","01778-762240");
        crateHotelList("বালাকা হোটেল","সদর রোড, ঢাকা","01789-255953");
        crateHotelList("হোটেল নদীরপাড়","সদর রোড, ঢাকা","01708-353836");
        crateHotelList("হোটেল সিটিসেন্টার","ফায়ার সার্ভিস রোড, ঢাকা।","01734-055863");
        crateHotelList("হোটেল পার্ক","সদর রোড, ঢাকা।","000000");
        crateHotelList("হোটেল ছোয়া আবাসিক","ঢাকা।","01720249193");

        crateHotelList("ফারুক সুইটস","1 সদর রোড, ঢাকা।","01719351453");
        crateHotelList("নিমন্ত্রণ কাবাব ঘর","আরামবাগ লেক, ঢাকা","01719764509");
        crateHotelList("মিজবান সুইড এন্ড রেস্টরেন্ট","চৌরাস্তা, ঢাকা।","01778099151");
        crateHotelList("চিকেন পয়েন্ট"," ঢাকা।","01712489922");
        crateHotelList(" জনপ্রিয় সিংগারা পয়েন্ট","কলেজ গেট, ঢাকা।","01814445276");
        crateHotelList("মজিদ হোটেল","নিউমার্কেট, ঢাকা।","01715924514");

        crateHotelList("কালিকাপর আবাসিক হোটেল","পুরাতন ফেরিঘাট রোড, ঢাকা।","01749596675");
        crateHotelList("হোটেল সাথি আবাসিক","মিঠা পুকুর রোড, ঢাকা।","01714660616");
        crateHotelList("হোটেল রুপসি বাংলা","ঢাকা।","01778762240");
        crateHotelList("হোটেল সাউত কিং","ঢাকা।","044162093");
        crateHotelList("হেটেল বনানী রেস্টুরেন্ট","সরকারী কলেজ রোড, ঢাকা।","044162275");
        crateHotelList("খান মহল রেস্টরেন্ট এন্ড কমিউনিটি সেন্টার","ঢাকা।","01774936110");
        crateHotelList("আল বারাকা হোটের এন্ড রেস্টুরেন্ট","ঢাকা।","01747588035");
        crateHotelList("জোনাকি হোটেল","ঢাকা।","01724768783");
        hotelList=new ArrayList<>();
        //**************************************************




        MyAdapter myAdapter=new MyAdapter();
        hotelListView.setAdapter(myAdapter);
        title.setText(TITLE);



    }//onCreate End>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //Create Hospital List Method**************
    private void createCurearlList(String name,String adress,String numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("adress",adress);
        hashMap.put("numbar",numbar);
        curearlList.add(hashMap);
    }



    //Create Hospital List Method**************
    private void createHospitalList(String name,String adress,String numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("adress",adress);
        hashMap.put("numbar",numbar);
        hospitalList.add(hashMap);
    }


    //Create L List Method**************
    private void crateHotelList(String name,String adress,String numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("adress",adress);
        hashMap.put("numbar",numbar);
        hotelList.add(hashMap);
    }


    //Create MyAdapter*****************************

    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.hospital_list,parent,false);

            ShimmerTextView hotelName=myView.findViewById(R.id.hotelName);
            ShimmerTextView hotelAdrss=myView.findViewById(R.id.hotelAdress);
            ShimmerTextView hotel_numbar=myView.findViewById(R.id.hotel_numbar);
            LottieAnimationView call_lottie=myView.findViewById(R.id.call_lottie);
            CardView cardView=myView.findViewById(R.id.cardView);

            Shimmer shimmer=new Shimmer();
            //shimmer.start(hotelName);
            shimmer.start(hotelAdrss);
            //shimmer.start(hotel_numbar);

            //Animation for CardView
            YoYo.with(Techniques.ZoomInUp).duration(900).repeat(0).playOn(cardView);


            //get String from arrayList
            hashMap=arrayList.get(position);
            String name=hashMap.get("name");
            String adress=hashMap.get("adress");
            String numbar=hashMap.get("numbar");

            hotelName.setText(name);
            hotelAdrss.setText(adress);
            hotel_numbar.setText(numbar);


            call_lottie.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent call=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+numbar));
                    startActivity(call);

                }
            });


            return myView;
        }

    }
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



}