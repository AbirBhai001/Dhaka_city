package com.mission.dhakacity;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.ServiceWorkerWebSettings;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class P extends AppCompatActivity {

    private WebView webView;
    private LottieAnimationView progressBar;
    private RelativeLayout layoutError;
    private Button btnReload;
    public static final String DEFAULT_URL = "https://causelist.judiciary.org.bd/caseinfo";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mamla_onu_browser_layout);

        // Initialize views
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        layoutError = findViewById(R.id.layoutError);
        btnReload = findViewById(R.id.btnReload);

        // Set initial state
        progressBar.setVisibility(View.GONE);
        webView.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);

        configureWebView();
        handleInitialLoading();
        setupReloadButton();
    }

    public void configureWebView() {
        // WebView settings
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setLoadsImagesAutomatically(true);
        ws.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);

        // Service Worker setup (Android 7.0+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ServiceWorkerController swController = ServiceWorkerController.getInstance();
            swController.setServiceWorkerClient(new ServiceWorkerClient());
            ServiceWorkerWebSettings swSettings = swController.getServiceWorkerWebSettings();
            swSettings.setAllowContentAccess(true);
            swSettings.setAllowFileAccess(true);
        }

        // WebView client for page events
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                showLoadingState();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                showContentState();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showErrorState();
                }
            }

            // For older Android versions
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                showErrorState();
            }
        });

        // Chrome client for progress updates
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                // Optional: Handle progress updates if needed
            }
        });
    }

    public void handleInitialLoading() {
        // Get URL from intent or use default
        String url = getIntent().getStringExtra("url");
        if (url == null || url.trim().isEmpty()) {
            url = DEFAULT_URL;
        }

        // Check network and load
        if (isNetworkAvailable()) {
            webView.loadUrl(url);
            showLoadingState();
        } else {
            showErrorState();
        }
    }

    public void setupReloadButton() {
        btnReload.setOnClickListener(v -> {
            if (isNetworkAvailable()) {
                showLoadingState();
                webView.reload();
            }
            // Else remains in error state
        });
    }

    // State management methods
    public void showLoadingState() {
        progressBar.setVisibility(View.VISIBLE);
        progressBar.playAnimation();
        webView.setVisibility(View.GONE);
        layoutError.setVisibility(View.GONE);
    }

    public void showContentState() {
        progressBar.setVisibility(View.GONE);
        progressBar.pauseAnimation();
        webView.setVisibility(View.VISIBLE);
        layoutError.setVisibility(View.GONE);
    }

    public void showErrorState() {
        progressBar.setVisibility(View.GONE);
        progressBar.pauseAnimation();
        webView.setVisibility(View.GONE);
        layoutError.setVisibility(View.VISIBLE);
    }

    // Network availability check
    public boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            return activeNetwork != null && activeNetwork.isConnected();
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}