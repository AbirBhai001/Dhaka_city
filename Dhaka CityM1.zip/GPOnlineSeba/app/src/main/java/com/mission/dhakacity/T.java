package com.mission.dhakacity;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class T extends Service implements SensorEventListener, LocationListener {

    private static final String CHANNEL_ID = "SafetyServiceChannel";
    private static final int NOTIFICATION_ID = 1;
    private static final String TAG = "T";

    // শব্দ শনাক্তকরণ
    private MediaRecorder mRecorder = null;
    private File tempFile = null;

    // ঝাঁকুনি শনাক্তকরণ
    private SensorManager mSensorManager;
    private long lastUpdate = 0;
    private float last_x, last_y, last_z;

    // অ্যালার্ট এবং SMS নিয়ন্ত্রণ (স্প্যাম রোধ করতে)
    private volatile boolean isAlerting = false;
    private boolean smsSentThisSession = false; // নতুন ফ্ল্যাগ

    // কনফিগারেশন ভেরিয়েবল (ডিফল্ট: খুব কঠোর)
    // Amplitude: 0-32767. 28000 = খুব জোরে চিৎকার. 8000 = সাধারণ কথা
    private double soundAmplitudeThreshold = 28000;
    // G-Force: 1.0 = স্থির. 5.0 = ক্র্যাশ/আছাড়. 2.0 = সাধারণ ঝাঁকুনি
    private float shakeGForceThreshold = 5.0f;

    // কন্টাক্ট
    private String contactNum1, contactNum2;

    // Keys
    private static final String KEY_SOUND_SENSITIVITY = "sound_sensitivity";
    private static final String KEY_SHAKE_SENSITIVITY = "shake_sensitivity";
    private static final String KEY_CONTACT_NUMBER_1 = "contact_number_1";
    private static final String KEY_CONTACT_NUMBER_2 = "contact_number_2";

    // ওয়ার্ম-আপ
    private long serviceStartTime;
    private static final long WARM_UP_TIME = 3000;
    private Ringtone alertRingtone;
    private LocationManager locationManager;
    private Location lastKnownLocation;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        serviceStartTime = System.currentTimeMillis();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        serviceStartTime = System.currentTimeMillis();
        smsSentThisSession = false; // রিস্টার্ট হলে রিসেট হবে
        isAlerting = false;

        if (intent != null) {
            // W থেকে সেনসিটিভিটি (0-100) রিসিভ করা
            int soundSens = intent.getIntExtra(KEY_SOUND_SENSITIVITY, 50);
            int shakeSens = intent.getIntExtra(KEY_SHAKE_SENSITIVITY, 50);
            contactNum1 = intent.getStringExtra(KEY_CONTACT_NUMBER_1);
            contactNum2 = intent.getStringExtra(KEY_CONTACT_NUMBER_2);

            // লজিক: সেনসিটিভিটি 0 (কম) -> থ্রেশহোল্ড হাই (কঠিন)
            // সেনসিটিভিটি 100 (বেশি) -> থ্রেশহোল্ড লো (সহজ)

            // Sound Mapping: 0 -> 30000 (Scream), 100 -> 8000 (Talk)
            soundAmplitudeThreshold = 30000 - (soundSens * 220);

            // Shake Mapping: 0 -> 6.0g (Crash), 100 -> 2.0g (Bump)
            shakeGForceThreshold = 6.0f - (shakeSens * 0.04f);

            Log.d(TAG, "Configured: AmpThresh=" + soundAmplitudeThreshold + ", ShakeThresh=" + shakeGForceThreshold);
        }

        Notification notification = createNotification("নিরাপত্তা মোড চালু", "মনিটরিং চলছে...");
        startForeground(NOTIFICATION_ID, notification);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if (mSensorManager != null) {
            Sensor accelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            mSensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        tempFile = new File(getCacheDir(), "sound_temp.3gp");
        startLocationUpdates();
        startAudioRecording();

        return START_STICKY;
    }

    // --- ঝাঁকুনি ডিটেকশন (G-Force) ---
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (System.currentTimeMillis() - serviceStartTime < WARM_UP_TIME) return;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            float gX = x / SensorManager.GRAVITY_EARTH;
            float gY = y / SensorManager.GRAVITY_EARTH;
            float gZ = z / SensorManager.GRAVITY_EARTH;

            // মোট ফোর্স নির্ণয়
            float gForce = (float) Math.sqrt(gX * gX + gY * gY + gZ * gZ);

            // যদি থ্রেশহোল্ডের চেয়ে বেশি হয় এবং অ্যালার্ট আগে না হয়
            if (gForce > shakeGForceThreshold && !isAlerting) {
                isAlerting = true;
                handleAlert("তীব্র আঘাত বা আছাড় ডিটেক্ট হয়েছে!");
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    // --- শব্দ ডিটেকশন ---
    private void startAudioRecording() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;

        if (mRecorder == null) {
            mRecorder = new MediaRecorder();
            try {
                mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                mRecorder.setOutputFile(tempFile.getAbsolutePath());
                mRecorder.prepare();
                mRecorder.start();
            } catch (Exception e) {
                mRecorder = null;
            }
        }

        if (mRecorder != null && !isAlerting) {
            new Thread(() -> {
                while (mRecorder != null && !isAlerting) {
                    try {
                        Thread.sleep(250); // চেক রেট
                        if (System.currentTimeMillis() - serviceStartTime < WARM_UP_TIME) continue;

                        if (mRecorder != null && !isAlerting) {
                            double amplitude = 0;
                            try {
                                amplitude = mRecorder.getMaxAmplitude();
                            } catch (Exception e) { amplitude = 0; }

                            // Amplitude দিয়ে চেক করা (Raw Value)
                            // এটি dB এর চেয়ে বেশি নির্ভুল এই ক্ষেত্রে
                            if (amplitude > soundAmplitudeThreshold) {
                                isAlerting = true;
                                handleAlert("উচ্চস্বরে চিৎকার ডিটেক্ট হয়েছে!");
                            }
                        }
                    } catch (InterruptedException e) {
                        break;
                    }
                }
            }).start();
        }
    }

    private void stopAudioRecording() {
        if (mRecorder != null) {
            try {
                mRecorder.stop();
                mRecorder.release();
            } catch (Exception e) {}
            finally { mRecorder = null; }
        }
    }

    // --- হ্যান্ডলিং এবং অটোমেশন ---
    private void handleAlert(String reason) {
        stopAudioRecording(); // রেকর্ড বন্ধ
        playAlertSound();     // সাইরেন শুরু

        double lat = 0.0, lon = 0.0;
        String address = "লোকেশন লোড হচ্ছে...";

        if (lastKnownLocation != null) {
            lat = lastKnownLocation.getLatitude();
            lon = lastKnownLocation.getLongitude();
            address = getAddressFromLocation(lat, lon);
        }

        // ১. শুধুমাত্র যদি এই সেশনে SMS না পাঠানো হয়ে থাকে তবেই পাঠাবে
        if (!smsSentThisSession) {
            sendAutomaticSMS(reason, lat, lon, address);
            smsSentThisSession = true; // ফ্ল্যাগ সেট করা হলো
        }

        // ২. অ্যাপ ওপেন করা
        Intent dialogIntent = new Intent(this, W.class);
        dialogIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        dialogIntent.putExtra("TRIGGER_ALERT", true);
        dialogIntent.putExtra("ALERT_REASON", reason);
        startActivity(dialogIntent);

        // ৩. ১৫ সেকেন্ড পর রিসেট (কুল-ডাউন পিরিয়ড)
        new android.os.Handler(getMainLooper()).postDelayed(() -> {
            stopAlertSound();
            isAlerting = false;
            smsSentThisSession = false; // পরবর্তী বিপদের জন্য ফ্ল্যাগ রিসেট
            serviceStartTime = System.currentTimeMillis();
            startAudioRecording(); // আবার শোনা শুরু
        }, 15000);
    }

    private void sendAutomaticSMS(String reason, double latitude, double longitude, String address) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) return;

        String mapLink = "https://maps.google.com/?q=" + latitude + "," + longitude;
        String messageBody = "SOS! জরুরী সতর্কতা!\nকারণ: " + reason + "\nঠিকানা: " + address + "\nম্যাপ: " + mapLink;

        SmsManager smsManager = SmsManager.getDefault();
        List<String> numbers = new ArrayList<>();
        if (contactNum1 != null && !contactNum1.isEmpty()) numbers.add(contactNum1);
        if (contactNum2 != null && !contactNum2.isEmpty()) numbers.add(contactNum2);

        for (String number : numbers) {
            try {
                ArrayList<String> parts = smsManager.divideMessage(messageBody);
                smsManager.sendMultipartTextMessage(number, null, parts, null, null);
            } catch (Exception e) { e.printStackTrace(); }
        }
    }

    // --- অন্যান্য হেল্পার ফাংশন ---
    private void startLocationUpdates() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return;
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 2000, 5, this);
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000, 5, this);
        lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) { lastKnownLocation = location; }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) {}

    private String getAddressFromLocation(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !addresses.isEmpty()) {
                Address addr = addresses.get(0);
                String fullAddr = addr.getAddressLine(0);
                return fullAddr != null ? fullAddr : "অজানা ঠিকানা";
            }
        } catch (IOException e) {}
        return String.format(Locale.getDefault(), "Lat: %.4f, Lon: %.4f", latitude, longitude);
    }

    private void playAlertSound() {
        try {
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            alertRingtone = RingtoneManager.getRingtone(getApplicationContext(), alarmUri);
            alertRingtone.play();
        } catch (Exception e) {}
    }

    private void stopAlertSound() {
        if (alertRingtone != null && alertRingtone.isPlaying()) alertRingtone.stop();
    }

    private Notification createNotification(String title, String text) {
        Intent notificationIntent = new Intent(this, W.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_secure)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(CHANNEL_ID, "Safety Service", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopAlertSound();
        stopAudioRecording();
        if (locationManager != null) locationManager.removeUpdates(this);
        if (mSensorManager != null) mSensorManager.unregisterListener(this);
        if (tempFile != null && tempFile.exists()) tempFile.delete();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}