package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.models.SlideModel;

import java.util.ArrayList;

public class F extends AppCompatActivity {

    ImageSlider imageSlider;


    //ArrayList for image slider
    ArrayList<SlideModel> imageList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.car_mamla_layout);

        imageSlider =findViewById(R.id.image_slider2);


        imageList.add(new SlideModel(R.drawable.car_mamla_slider1,null));
        imageList.add(new SlideModel(R.drawable.car_mamla_slider2,null));
        imageList.add(new SlideModel(R.drawable.car_mamla_slider3,null));

        imageSlider.setImageList(imageList);


    }
}