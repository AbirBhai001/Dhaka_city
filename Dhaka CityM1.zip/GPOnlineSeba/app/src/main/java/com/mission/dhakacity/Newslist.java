package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.ArrayList;
import java.util.HashMap;

public class Newslist extends AppCompatActivity {

    ListView newsListView;
    HashMap <String,String>hashMap=new HashMap<>();
    ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newslist);

        newsListView=findViewById(R.id.newsListView);

        //Make NewsList
        createList(R.drawable.ajker_dhaka);
        createList(R.drawable.news_dhaka);
        createList(R.drawable.dhaka_news);
        createList(R.drawable.prothomalo);
        createList(R.drawable.alocto_khbr);
        createList(R.drawable.bbc_news);
        createList(R.drawable.bd_dli);
        createList(R.drawable.ajker_brta);
        //**********************************************


        MyAdapter myAdapter=new MyAdapter();
        newsListView.setAdapter(myAdapter);

    }//onCreate End>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //CreateList****************
    private void createList(int drawable){
        hashMap=new HashMap<>();
        hashMap.put("image",String.valueOf(drawable));
        arrayList.add(hashMap);
    }
    //****************************************

    //Create MyAdapter**********************

    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.news_list,parent,false);

            ImageView newsCover=myView.findViewById(R.id.newsCover);
            CardView newsItem=myView.findViewById(R.id.newsItem);


            hashMap=arrayList.get(position);

            String cImage=hashMap.get("image");
            int image=Integer.parseInt(cImage);
            newsCover.setImageResource(image);

            //Animation for newsItem https://www.ajkerpatuakhali.com/======https://www.jagonews24.com/bangladesh/barisal/patuakhali
            YoYo.with(Techniques.ZoomInUp).duration(900).repeat(0).playOn(newsItem);

            newsItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (position==0){
                        E.url="https://www.diamondnews24.com/todays-dhaka";
                        startActivity(new Intent(Newslist.this, E.class));
                    }
                    else if (position==1){
                        E.url="https://dhakamail.com/latest-news";
                        startActivity(new Intent(Newslist.this, E.class));
                    }
                    else if (position==2){
                        E.url="https://www.dhakanews24.com/";
                        startActivity(new Intent(Newslist.this, E.class));
                    }
                    else if (position==3){
                        E.url="https://www.prothomalo.com/";
                        startActivity(new Intent(Newslist.this, E.class));
                    }


                    if (position==4){
                        E.url="https://alochitokhabor.com/";
                        startActivity(new Intent(Newslist.this, E.class));
                    }

                    else if (position==5){
                        E.url="https://www.bbc.com/bengali";
                        startActivity(new Intent(Newslist.this, E.class));
                    }


                    else if (position==6){
                        E.url="https://www.bd-pratidin.com/";
                        startActivity(new Intent(Newslist.this, E.class));
                    }

                    else if (position==7){
                        E.url="https://dailyajkerbarta.com/";
                        startActivity(new Intent(Newslist.this, E.class));
                    }



                }
            });

            return myView;
        }
    }

}