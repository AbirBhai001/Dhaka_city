package com.mission.dhakacity;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;


import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import java.util.ArrayList;
import java.util.HashMap;


public class M extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private static final String ONESIGNAL_APP_ID = "c7612ad0-a958-4066-90d3-0d241d0b247c";

    FirebaseRemoteConfig remoteConfig;



    //Initialize Veriable
    ImageSlider imageSlider;
   // LottieAnimationView lottieCall;
    GridView gridView;

    //Array for GridView
    HashMap<String,String>hashMap=new HashMap<>();
    ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();

    //ArrayList for image slider
    ArrayList<SlideModel> imageList = new ArrayList<>();
    TextView marqueeText;
    LinearLayout btncontact, btnlocation, nirapotta;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private LinearLayout dot;
    LinearLayout profile;
    LottieAnimationView btnAiAction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //Audience ntrk
        // AudienceNetworkAds.initialize(M.this);





        nirapotta = findViewById(R.id.nirapotta);
        nirapotta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(M.this, W.class);
                startActivity(intent);
            }
        });

        btnlocation = findViewById(R.id.btnlocation);
        btnlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(M.this, B.class);
                startActivity(intent);
            }
        });

        btncontact = findViewById(R.id.btncontact);
        btncontact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(M.this, O.class);
                startActivity(intent);
            }
        });

        btnAiAction = findViewById(R.id.btnAiAction);
        btnAiAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(M.this, O.class);
                startActivity(intent);
            }
        });

/// //////////////////////////////////////////////////////////
        TextView marqueeText = findViewById(R.id.marqueeText);
        // মারকী চালু রাখতে অবশ্যই সিলেক্টেড
        marqueeText.setSelected(true);

        drawerLayout   = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        dot            = findViewById(R.id.dot);
        profile = findViewById(R.id.profile);

        // ড্রয়ার বাটন ক্লিক লিসেনার: ক্লিক করলে ড্রয়ার ওপেন হবে:contentReference[oaicite:10]{index=10}।
        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(M.this, A.class);
                startActivity(intent);
            }
        });




        // ২. Toolbar + Toggle সংযোগ
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // ৩. bringToFront
        drawerLayout.bringToFront();
        navigationView.bringToFront();

        // ৪. Listener সেট
        navigationView.setNavigationItemSelectedListener(this);

        // ৫. Intent-flag থেকে ড্রয়ার নিজে খোলা (যদি প্রয়োজন)
        if (getIntent().getBooleanExtra("openDrawer", false)) {
            drawerLayout.openDrawer(GravityCompat.START);
        }




     /*   // NavigationView আইটেম সিলেক্ট লিসেনার—জেকোন মেনু আইটেমে ক্লিক করলে কর্ম সম্পন্ন করবে:contentReference[oaicite:11]{index=11}।
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                drawerLayout.closeDrawer(GravityCompat.START);
                int id = menuItem.getItemId();

                if (id == R.id.nav_dark_them) {
                    toggleDarkMode();
                    return true;
                } else if (id == R.id.nav_about_app) {
                    showAboutApp();
                    return true;
                } else if (id == R.id.nav_about_dev) {
                    showAboutDeveloper();
                    return true;
                } else if (id == R.id.nav_share_app) {
                    shareApp();
                    return true;
                } else if (id == R.id.nav_rate_app) {
                    rateApp();
                    return true;
                } else if (id == R.id.nav_contact) {
                    contactDeveloper();
                    return true;
                } else if (id == R.id.nav_report_bug) {
                    reportBug();
                    return true;
                }
                return false;
            }
        }); */








        /*setTitle("Date & Time");

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(android.icu.text.DateFormat.FULL).format(calendar.getTime());


        marqueeText = findViewById(R.id.marqueeText);
        marqueeText.setSelected(true);


        //app update in phone show code// j j kaj update korar sob kechu kore...
        // Firebase a geya patuakhali Online seba j vartion ase dawua ase tar shate 1 plas kore deban..
        //tahole otomatik user ar kase update chabe..
        // Firebase---Patuakhali App---Build---Remot config---neche newVersionCode eidt kote 1bareya deban---save---publice

        int currentVersionCode;
        currentVersionCode = getCurrentVersionCode();
        Log.d("myApp",String.valueOf(currentVersionCode));

        remoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(2)
                .build();
        remoteConfig.setConfigSettingsAsync(configSettings);
        remoteConfig.fetchAndActivate().addOnCompleteListener(new OnCompleteListener<Boolean>() {
            @Override
            public void onComplete(@NonNull Task<Boolean> task) {
                if (task.isSuccessful()){
                    final String newVersionCode = remoteConfig.getString("newVersionCode");
                    if (Integer.parseInt(newVersionCode) > getCurrentVersionCode()){
                        showUpdateDialogBox();

                    }
                }
            }
        }); */




        //Start onCreate**********************************************
        //*************************************************************
        //**************************************************************

        //Find variable
        imageSlider=findViewById(R.id.image_slider);
        gridView=findViewById(R.id.gridView);
       // lottieCall=findViewById(R.id.lottieCall);
        //=================পরিচয়=============



        //create image slider***************slide_gp1
        imageList.add(new SlideModel(R.drawable.dhaka_slid1,ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel(R.drawable.dhaka_sld2,ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel(R.drawable.dhaka_sld3,ScaleTypes.CENTER_CROP));

        imageList.add(new SlideModel(R.drawable.dhaka_sld4,ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel(R.drawable.dhaka_sld5,ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel(R.drawable.dhaka_sld6,ScaleTypes.CENTER_CROP));
        imageList.add(new SlideModel(R.drawable.dhaka_sld7,ScaleTypes.CENTER_CROP));
        imageSlider.setImageList(imageList);
        //**************************************************


        //Make Gride Item**********************************
        makeItem(R.drawable.news,"খবর");
        makeItem(R.drawable.blood,"ব্লাড ডোনার");
        makeItem(R.drawable.hospital,"হাসপাতাল");
        makeItem(R.drawable.doctor,"ডাক্তার");
        makeItem(R.drawable.ambulance,"এ্যাম্বুলেন্স");
        makeItem(R.drawable.fire_track,"ফায়ার সার্ভিস");
        makeItem(R.drawable.emergency,"জরুরী সেবা");
        makeItem(R.drawable.gdmamla_icon,"জিডি বা মামলা");
        makeItem(R.drawable.pulish,"পুলিশ স্টেশন");
        makeItem(R.drawable.rab,"র‌্যাব সেবা");
        makeItem(R.drawable.bike_icon,"গাড়ির মামলা?");
        makeItem(R.drawable.online,"ই-সেবা");
        makeItem(R.drawable.curear_icon,"কুরিয়ার সার্ভিস");
        makeItem(R.drawable.lowyar,"আইনজীবী");
        makeItem(R.drawable.news_reporter,"সাংবাদিক");
        makeItem(R.drawable.bus,"বাস টিকেট");
        makeItem(R.drawable.train,"রেল সেবা");
        makeItem(R.drawable.polli_biddut,"পল্লি বিদ্যুৎ");
        makeItem(R.drawable.resturent,"রেস্টুরেন্ট");
        makeItem(R.drawable.hotel_bed,"হোটেল");
        makeItem(R.drawable.police_cliyarens_icon,"পুলিশ ক্লিয়ারেন্স");
        makeItem(R.drawable.collage_list,"কলেজ লিস্ট");

        makeItem(R.drawable.admition_icon,"ভর্তি প্রস্তুতি");
        makeItem(R.drawable.result_icon,"রেজাল্ট দেখুন");
        makeItem(R.drawable.job_icon,"চাকরি খুজুন");
        makeItem(R.drawable.icon_mcq,"কুইজ");

        makeItem(R.drawable.mamla_onu_icon,"মামলা অনুসন্ধান");
        makeItem(R.drawable.visiting,"দর্শনীয় স্থান");
        //makeItem(R.drawable.aboutapp_icon,"A App");
        //makeItem(R.drawable.developer,"A Us");
        //***************************************************************


        //==
        MyAdapter myAdapter=new MyAdapter();
        gridView.setAdapter(myAdapter);

        //LottieCall for Top Lay
        /*
        lottieCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:999"));
                startActivity(call);
            }
        }); */





    }
    //End onCreate**********************************************
    //==app update in phone.. show code//..update code ar baki ongsho.. j j kaj update korar sob kechu kore..
    // Firebase a geya patuakhali Online seba j vartion dawua ase tar shate 1 plas kore deban..
    //tahole otomatik user ar kase update chaibe..sustam
    // Firebase---Patuakhali App---Build---Remot config---neche newVersionCode eidt kote 1bareya deban---save---publice
    private int getCurrentVersionCode(){
        PackageInfo packageInfo = null;
        try {
            packageInfo = getPackageManager().getPackageInfo(getPackageName(),0);
        }catch (Exception e){
            Log.d("myApp",e.getMessage());
        }
        return  packageInfo.versionCode;
    }
  /*  private void showUpdateDialogBox() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setIcon(R.drawable.app_icon)
                .setTitle(getString(R.string.new_update))
                .setMessage(getString(R.string.new_update_text))
                .setCancelable(false)
                .setPositiveButton(Html.fromHtml("<h4 width:200px style=\"background-color:rgb(57, 233, 145);\" > Update Now. </h4>"), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.playStoreLink))));
                        }catch (Exception e){
                            Toast.makeText(M.this, "Something Wrong ! Please try again...", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).show();

    } */
    //*************************************************************
    //**************************************************************





    //Create Method for Grid Item
    private void makeItem(int drawable,String itemTitle){
        hashMap=new HashMap<>();
        hashMap.put("image",String.valueOf(drawable));
        hashMap.put("title",itemTitle);
        arrayList.add(hashMap);
    }
    //*********************************************



//**********MyAdapter Start here**********************************
    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.grid_item,viewGroup,false);

            ImageView itemImage=myView.findViewById(R.id.itemImage);
            ShimmerTextView itemTitle=myView.findViewById(R.id.itemTitle);
            Shimmer shimmer=new Shimmer();
            CardView serviceItem=myView.findViewById(R.id.serviceItem);

            shimmer.start(itemTitle);
            YoYo.with(Techniques.ZoomInUp).duration(1000).repeat(0).playOn(serviceItem);

            hashMap=arrayList.get(position);
            String simage=hashMap.get("image");
            String title=hashMap.get("title");

            int image=Integer.parseInt(simage);

            itemImage.setImageResource(image);
            itemTitle.setText(""+title);


            serviceItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {




                    if (itemTitle.getText().toString().contains("ই-সেবা")){

                        startActivity(new Intent(M.this, G.class));
                    }
                    else if (itemTitle.getText().toString().contains("ব্লাড ডোনার")){
                        startActivity(new Intent(M.this, X.class));
                        X.TITLE="আপনার ঠিকানা সিলেক্ট করুন।";
                        Toast.makeText(M.this, "রক্তদান সেবায় আপনাকে স্বাগতম", Toast.LENGTH_SHORT).show();
                    }
                    else if (itemTitle.getText().toString().contains("রেস্টুরেন্ট")){
                        E.url="https://www.foodpanda.com.bd/";
                        startActivity(new Intent(M.this, E.class));
                    }
                    else if (itemTitle.getText().toString().contains("বাস টিকেট")){
                        E.url="https://www.shohoz.com/bus-tickets";
                        startActivity(new Intent(M.this, E.class));
                    }


                    else if (itemTitle.getText().toString().contains("ভর্তি প্রস্তুতি")){
                        E.url="https://www.admissionwar.com/";
                        startActivity(new Intent(M.this, E.class));
                    }

                    else if (itemTitle.getText().toString().contains("চাকরি খুজুন")){
                        E.url="https://bdjobnews.com/bn/";
                        startActivity(new Intent(M.this, E.class));
                    }

                   /* else if (itemTitle.getText().toString().contains("পুলিশ ক্লিয়ারেন্স")){
                        E.url="https://pcc.police.gov.bd/ords/f?p=PCC:REGISTRATION::NO:4::";
                          startActivity(new Intent(M.this,E.class));
                    }*/
                   /* else if (itemTitle.getText().toString().contains("পুলিশ ক্লিয়ারেন্স")){
                        P.url="https://pcc.police.gov.bd/ords/f?p=PCC:REGISTRATION::";
                        startActivity(new Intent(M.this,P.class));
                    } */

                    else if (itemTitle.getText().toString().contains("পুলিশ ক্লিয়ারেন্স")) {
                        Intent intent = new Intent(M.this, P.class);
                        intent.putExtra("url", "https://causelist.judiciary.org.bd/caseinfo");
                        startActivity(intent);
                        Toast.makeText(M.this, "Please Wait for Next Update!", Toast.LENGTH_SHORT).show();
                    }





                    else if (itemTitle.getText().toString().contains("রেল সেবা")){
                        E.url="https://eticket.railway.gov.bd/";
                        startActivity(new Intent(M.this, E.class));
                    }
                    else if (itemTitle.getText().toString().contains("ডাক্তার")){
                        Intent intent = new Intent(M.this, P.class);
                        intent.putExtra("url", "https://daktarbook.com/district/doctor/73");
                        startActivity(intent);
                        Toast.makeText(M.this, "বিশেষজ্ঞ ডাক্তারি সেবায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();
                    }
                    else if (itemTitle.getText().toString().contains("মামলা অনুসন্ধান")){
                        Intent intent = new Intent(M.this, P.class);
                        intent.putExtra("url", "https://causelist.judiciary.org.bd/caseinfo0");
                        startActivity(intent);
                       // P.url="https://causelist.judiciary.org.bd/caseinfo";
                        //startActivity(new Intent(M.this,P.class));
                        Toast.makeText(M.this, "Working! Please Wait For Next Update!", Toast.LENGTH_SHORT).show();
                    }

                    ///Patuakhali tour: https://vromonguide.com/location/patuakhali
                    else if (itemTitle.getText().toString().contains("দর্শনীয় স্থান")){
                        Intent intent = new Intent(M.this, P.class);
                        intent.putExtra("url", "https://vromonguide.com/location/dhaka");
                        startActivity(intent);
                        //P.url="https://bangla.tourtoday.com.bd/category/tourist-spots-in-barisal/patuakhali-tour/";
                        //startActivity(new Intent(M.this,P.class));
                        //E.url="https://bangla.tourtoday.com.bd/category/tourist-spots-in-barisal/patuakhali-tour/";
                       // startActivity(new Intent(M.this,E.class));
                        Toast.makeText(M.this, "ঢাকা দর্শনীয় স্থানে* আপনাকে স্বাগতম!!!", Toast.LENGTH_SHORT).show();

                    }

                    else if (itemTitle.getText().toString().contains("খবর")){
                        startActivity(new Intent(M.this,Newslist.class));
                        Toast.makeText(M.this, "দৈনন্দিন খবরেে আপনাকে স্বাগতম*!!", Toast.LENGTH_SHORT).show();
                    }
                    //=======
                    else if (itemTitle.getText().toString().contains("ফায়ার সার্ভিস")){
                        H.arrayList= H.fireseviceList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="ঢাকা ফায়ার সার্ভিস";
                        Toast.makeText(M.this, "ফায়ার সার্ভিস সেবায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();
                    }

                    else if (itemTitle.getText().toString().contains("পুলিশ স্টেশন")){
                        H.arrayList= H.pulishList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="ঢাকা পুলিশ";
                        Toast.makeText(M.this, "প্রশাসনিক সহায়তায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();

                    }


                    else if (itemTitle.getText().toString().contains("এ্যাম্বুলেন্স")){
                        H.arrayList= H.ambulenceList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="ঢাকা এ্যাম্বুলেন্স সার্ভিস";
                        Toast.makeText(M.this, "এ্যাম্বুলেন্স সার্ভিসে আপনাকে স্বাগতম।", Toast.LENGTH_SHORT).show();
                    }






                    else if (itemTitle.getText().toString().contains("পল্লি বিদ্যুৎ")){
                        H.arrayList= H.polliBidyutList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="ঢাকা পল্লিবিদ্যুৎ";
                    }
                    else if (itemTitle.getText().toString().contains("জরুরী সেবা")){
                        H.arrayList= H.helpLineList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="বিনামূল্যে জরুরী সেবা পেতে ফোন করুন";
                        Toast.makeText(M.this, "জরুরী সেবায় আপনাকে স্বাগতম!!!", Toast.LENGTH_SHORT).show();
                    }
                    //==========colage ad
                    else if (itemTitle.getText().toString().contains("কলেজ লিস্ট")){
                        H.arrayList= H.collageList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE="ঢাকা কলেজ লিস্ট ও যোগাযোগ ব্যবস্থা।";
                    }

                    else if (itemTitle.getText().toString().contains("র‌্যাব")){
                        H.arrayList= H.rabList;
                        startActivity(new Intent(M.this, H.class));
                        H.TITLE=" অপরাধ দমনে র‌্যাবকে তথ্য দিন ";
                        Toast.makeText(M.this, "র‌্যাব সেবায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();
                    }





                    else if (itemTitle.getText().toString().contains("হাসপাতাল")){
                        L.arrayList= L.hospitalList;
                        startActivity(new Intent(M.this, L.class));
                        L.TITLE="ঢাকা সরকারি বেসরকারি হাসপাতাল সমূহ";
                    }

                    else if (itemTitle.getText().toString().contains("হোটেল")){
                        L.arrayList= L.hotelList;
                        startActivity(new Intent(M.this, L.class));
                        L.TITLE="ঢাকা সদর রেষ্টুরেন্ট,হোটেল ও আবাসন";
                    }
                    //==
                    else if (itemTitle.getText().toString().contains("কুরিয়ার সার্ভিস")){
                        L.arrayList= L.curearlList;
                        startActivity(new Intent(M.this, L.class));
                        L.TITLE="কুরিয়ার সার্ভিস সেবায়* আপনাকে স্বাগতম।";
                    }
                    ///////////////////=============
                    //==
                    else if (itemTitle.getText().toString().contains("রেজাল্ট দেখুন")){
                        Toast.makeText(M.this, "Please Wait For Next Update!", Toast.LENGTH_SHORT).show();
                    }


                    else if (itemTitle.getText().toString().contains("আইনজীবী")){
                        D.TITEL="প্যানেল আইনজীবীদের তালিকা ঢাকা";
                        D.arrayList= D.lowearList;
                        startActivity(new Intent(M.this, D.class));
                        Toast.makeText(M.this, "আইনজীবি সহায়তায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();
                    }
                    else if (itemTitle.getText().toString().contains("সাংবাদিক")){
                        startActivity(new Intent(M.this, U.class));
                        Toast.makeText(M.this, "ঢাকা সাংবাদিক সেবায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();
                    }

                  /*  else if (itemTitle.getText().toString().contains("A Us")){
                        startActivity(new Intent(M.this,A.class));
                    } */
                    //========java & layout file khulte hobe...
                    else if (itemTitle.getText().toString().contains("জিডি বা মামলা")){
                        startActivity(new Intent(M.this, I.class));
                        Toast.makeText(M.this, "জিডি ও মামলা বিষয়ক সকল তথ্য জানুন।", Toast.LENGTH_SHORT).show();

                    }

                    else if (itemTitle.getText().toString().contains("গাড়ির মামলা?")){
                        startActivity(new Intent(M.this, F.class));
                        Toast.makeText(M.this, "আইনি সেবায় আপনাকে স্বাগতম!!", Toast.LENGTH_SHORT).show();

                    }


                    else if (itemTitle.getText().toString().contains("A App")){
                        startActivity(new Intent(M.this, C.class));

                    }

                    // Mcq Exam


                    else if (itemTitle.getText().toString().contains("কুইজ")){
                        startActivity(new Intent(M.this, N.class));



                    }







                }
            });



            return myView;
        }
    }
    //***************End of MyAdapter************************************

             /*** ৩.১ ডার্ক মোড টগল ফাংশন ***/
             private void toggleDarkMode() {
                 int currentMode = getResources().getConfiguration().uiMode &
                         android.content.res.Configuration.UI_MODE_NIGHT_MASK;

                 // যদি বর্তমানে লাইট মোড, তাহলে ডার্কে স্যুইচ করো:contentReference[oaicite:12]{index=12}।
                 if (currentMode == android.content.res.Configuration.UI_MODE_NIGHT_NO) {
                     AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                     Toast.makeText(this, "ডার্ক মোড চালু হয়েছে", Toast.LENGTH_SHORT).show();
                 } else {
                     AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                     Toast.makeText(this, "লাইট মোড চালু হয়েছে", Toast.LENGTH_SHORT).show();
                 }
             }

             /*** ৩.২ অ্যাপ সম্পর্কে ***/
             private void showAboutApp() {
                 Intent intent = new Intent(this, A.class);
                 startActivity(intent);
             }

             /*** ৩.৩ ডেভেলপার সম্পর্কে ***/
             private void showAboutDeveloper() {
                 Intent intent = new Intent(this, C.class);
                 startActivity(intent);
             }

             /*** ৩.৪ অ্যাপ শেয়ার ***/
             private void shareApp() {
                 Intent shareIntent = new Intent(Intent.ACTION_SEND);
                 shareIntent.setType("text/plain");
                 // আপনার Play Store লিঙ্ক বা যেকোন App URL দিন:contentReference[oaicite:13]{index=13}
                 String shareText = "এই অ্যাপটি দেখুন: https://play.google.com/store/apps/details?id=" + getPackageName();
                 shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
                 startActivity(Intent.createChooser(shareIntent, "অ্যাপ শেয়ার করুন"));
             }

             /*** ৩.৫ রেটিং (৫ স্টার) ***/
             private void rateApp() {
                 Uri uri = Uri.parse("market://details?id=" + getPackageName());
                 Intent rateIntent = new Intent(Intent.ACTION_VIEW, uri);
                 // যদি Play Store অ্যাপ না থাকে, তাহলে ব্রাউজারে খুলবে:contentReference[oaicite:14]{index=14}
                 rateIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY |
                         Intent.FLAG_ACTIVITY_NEW_DOCUMENT |
                         Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                 try {
                     startActivity(rateIntent);
                 } catch (ActivityNotFoundException e) {
                     // কোন রকমের Play Store চালু না হলে ওয়েব ব্রাউজারে ওপেন করো:contentReference[oaicite:15]{index=15}
                     Uri webUri = Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName());
                     Intent webIntent = new Intent(Intent.ACTION_VIEW, webUri);
                     startActivity(webIntent);
                 }
             }

             /*** ৩.৬ যোগাযোগ (ইমেইল) ***/
             private void contactDeveloper() {
                 Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                 emailIntent.setData(Uri.parse("missionasrafi@gmail.com")); // আপনার ইমেইল দিন:contentReference[oaicite:16]{index=16}
                 emailIntent.putExtra(Intent.EXTRA_SUBJECT, "অ্যাপ সম্পর্কে প্রশ্ন");
                 try {
                     startActivity(Intent.createChooser(emailIntent, "ইমেইল পাঠান"));
                 } catch (ActivityNotFoundException e) {
                     Toast.makeText(this, "কোন ইমেইল অ্যাপ ইনস্টল নেই", Toast.LENGTH_SHORT).show();
                 }
             }

             /*** ৩.৭ ভুল পেলে রিপোর্ট (বাগ) ***/
             private void reportBug() {
                 // আপনি চাইলে একটি ইমেইল বা বিশেষ ফর্মিং ব্যবহার করে বাগ রিপোর্ট করতে পারেন:contentReference[oaicite:17]{index=17}
                 Intent bugIntent = new Intent(Intent.ACTION_SENDTO);
                 bugIntent.setData(Uri.parse("missionasrafi@gmail.com")); // বাগ রিপোর্টের ইমেইল:contentReference[oaicite:18]{index=18}
                 bugIntent.putExtra(Intent.EXTRA_SUBJECT, "বাগ রিপোর্ট");
                 bugIntent.putExtra(Intent.EXTRA_TEXT, "অ্যাপে এই ত্রুটি বা বাগ দেখা দিয়েছে: ");
                 try {
                     startActivity(Intent.createChooser(bugIntent, "বাগ রিপোর্ট করুন"));
                 } catch (ActivityNotFoundException e) {
                     Toast.makeText(this, "ইমেইল অ্যাপ পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
                 }
             }









    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        drawerLayout.closeDrawer(GravityCompat.START);
        int itemId = menuItem.getItemId();
        if (itemId == R.id.nav_dark_them) {
            toggleDarkMode();
            return true;
        } else if (itemId == R.id.nav_about_app) {
            startActivity(new Intent(this, A.class));
            return true;
            // ... অন্য সকল আইটেম
        } else if (itemId == R.id.nav_about_dev) {
            startActivity(new Intent(M.this, C.class));
            return true;
        } else if (itemId == R.id.nav_share_app) {
            shareApp();
            return true;
        } else if (itemId == R.id.nav_rate_app) {
            rateApp();
            return true;
        } else if (itemId == R.id.nav_contact) {
            contactDeveloper();
            return true;
        } else if (itemId == R.id.nav_report_bug) {
            reportBug();
            return true;
        }
        return false;
    }




             //********onBackPressed Start here******************************************
    private static final int TIME_INTERVAL = 2000; // # milliseconds, desired
    private long mBackPressed;

    // When user click bakpress button this method is called
    @Override
    public void onBackPressed() {

        // When landing in home screen

            if (mBackPressed + TIME_INTERVAL > System.currentTimeMillis()) {

                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);

            } else {

                Toast.makeText(getBaseContext(), "Press again to exit",
                        Toast.LENGTH_SHORT).show();
            }

            mBackPressed = System.currentTimeMillis();




    } // end of onBackpressed method

    //#############################################################################################




}