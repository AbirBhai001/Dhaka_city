package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import java.util.ArrayList;
import java.util.HashMap;

public class X extends AppCompatActivity {

    TextView pageTitle;

    GridView gridView;
    HashMap<String,String>hashMap=new HashMap<>();
    ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();

    public static String TITLE="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upozila);

        gridView=findViewById(R.id.gridView);
        pageTitle=findViewById(R.id.pageTitle);


        //Make Item>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


        makeItem(R.drawable.blood,"শেরেবাংলা নগর");
        makeItem(R.drawable.blood,"বকশিবাজার");
        makeItem(R.drawable.blood,"ধানমন্ডি এলাকা");
        makeItem(R.drawable.blood,"মিরপুর");
        makeItem(R.drawable.blood,"উত্তারা");
        makeItem(R.drawable.team_icon,"সিনিয়ার সেচ্ছাসেবী");
        makeItem(R.drawable.f_g,"অথবা পোস্ট করুন");


        MyAdapter myAdapter=new MyAdapter();
        gridView.setAdapter(myAdapter);
        pageTitle.setText(TITLE);


    } //Oncreate end


    //Create method for Item>>>>>>>>>>>>>>>>>>>>>>>>>
    private void makeItem(int drawable,String itemTitle){
        hashMap=new HashMap<>();
        hashMap.put("image",String.valueOf(drawable));
        hashMap.put("title",itemTitle);
        arrayList.add(hashMap);
    }

    //Create MyAdapter>>>>>>>>>>>>>>>>>>>>>>>>>>>
    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.grid_item,viewGroup,false);

            ImageView itemImage=myView.findViewById(R.id.itemImage);
            ShimmerTextView itemTitle=myView.findViewById(R.id.itemTitle);
            Shimmer shimmer=new Shimmer();
            CardView serviceItem=myView.findViewById(R.id.serviceItem);

            shimmer.start(itemTitle);
            YoYo.with(Techniques.ZoomInUp).duration(1000).repeat(0).playOn(serviceItem);

            hashMap=arrayList.get(position);
            String simage=hashMap.get("image");
            String title=hashMap.get("title");

            int image=Integer.parseInt(simage);

            itemImage.setImageResource(image);
            itemTitle.setText(""+title);


            serviceItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (itemTitle.getText().toString().contains("শেরেবাংলা নগর")){
                        D.arrayList= D.sadarList;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো রক্তের প্রয়োজনে ফোন করুন।";
                        Toast.makeText(X.this, "শীঘ্রই আরো সুবিধা আসছে", Toast.LENGTH_SHORT).show();
                    }
                    else if (itemTitle.getText().toString().contains("বকশিবাজার")){
                        D.arrayList= D.muksudpurList;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো রক্তের প্রয়োজনে ফোন করুন।";
                    }
                    else if (itemTitle.getText().toString().contains("ধানমন্ডি এলাকা")){
                        D.arrayList= D.kasiyaniList;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো রক্তের প্রয়োজনে ফোন করুন।";
                    }
                    else if (itemTitle.getText().toString().contains("মিরপুর")){
                        D.arrayList= D.tungiparaList;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো রক্তের প্রয়োজনে ফোন করুন।";
                    }
                    else if (itemTitle.getText().toString().contains("উত্তারা")){
                        D.arrayList= D.kotaliparaList;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো রক্তের প্রয়োজনে ফোন করুন।";
                    }
                    else if (itemTitle.getText().toString().contains("সিনিয়ার সেচ্ছাসেবী")){
                        D.arrayList= D.sinour_secchasebi;
                        startActivity(new Intent(X.this, D.class));
                        D.TITEL="যেকোনো মানবিক কাজের জন্য ফোন করুন।";
                        Toast.makeText(X.this, "শীঘ্রই আসছে-কাজ চলমান রয়েছে", Toast.LENGTH_SHORT).show();

                    }

                    else if (itemTitle.getText().toString().contains("অথবা পোস্ট করুন")){
                        E.url="https://web.facebook.com/groups/2215664985384280";
                        startActivity(new Intent(X.this, E.class));
                    }




                }
            });



            return myView;
        }
    }




}