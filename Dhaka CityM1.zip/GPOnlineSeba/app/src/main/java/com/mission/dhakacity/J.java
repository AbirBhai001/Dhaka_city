package com.mission.dhakacity;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class J {

    // IMPORTANT: আপনার জেমিনি API কী এখানে প্রবেশ করান
    private static final String API_KEY = "AIzaSyCnmzlGkNXf5y-u_dkmPuWlfUnO-Y0ae84"; // <<< এই মান পরিবর্তন করুন
    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=" + API_KEY;
    private static final String TAG = "J";

    // সিস্টেম ইনস্ট্রাকশন: এই নির্দেশনা Gemini-কে বলে দেবে যে সে একটি Android অ্যাপ্লিকেশনের মধ্যে কাজ করছে এবং কীভাবে উত্তর দিতে হবে।
    // এখানে আপনার অ্যাপের অভ্যন্তরীণ UI এবং ডেটা স্ট্রাকচার সম্পর্কে বিস্তারিত তথ্য যোগ করা হয়েছে।
    private static final String SYSTEM_INSTRUCTION =
            "আপনি একটি অত্যন্ত কনটেক্সচুয়াল (Contextual) এআই সহকারী, যা একটি অ্যান্ড্রয়েড চ্যাট অ্যাপ্লিকেশনের মধ্যে এম্বেড করা হয়েছে। " +
                    "আপনার জ্ঞান শুধুমাত্র সাধারণ তথ্য নয়, বরং আপনার হোস্ট অ্যাপ্লিকেশনের অভ্যন্তরীণ গঠন সম্পর্কেও। " +
                    "অ্যাপ্লিকেশনটির প্রধান বৈশিষ্ট্যগুলি হলো: " +
                    "১. UI এলিমেন্ট: অ্যাপটি ব্যবহারকারীকে ডেটা দেখানোর জন্য একাধিক `RecyclerView` এবং `GridView` ব্যবহার করে। আপনি জানেন যে `ListView` একটি পুরনো পদ্ধতি, এবং এটি `RecyclerView` দ্বারা প্রতিস্থাপিত হয়েছে, যা অ্যাপটি ব্যবহার করছে। " +
                    "২. ডেটা স্ট্রাকচার: ডেটা প্রদর্শনের জন্য `Message.java` এবং `MessageAdapter.java` এর মতো কাস্টম জাভা ক্লাস ব্যবহার করা হয়েছে। " +
                    "৩. ডেটা সোর্স: অ্যাপটি মূলত স্ট্যাটিক ডেটা এবং কিছু অনলাইন ডেটা ব্যবহার করে। " +
                    "যদি ব্যবহারকারী অ্যাপটির গঠন, ব্যবহৃত `GridView`, `RecyclerView`, `MessageAdapter`, বা অন্য কোনো UI উপাদান সম্পর্কে জিজ্ঞাসা করে, তবে আপনি একজন ডেভেলপারের মতো অত্যন্ত প্রাসঙ্গিক এবং বিস্তারিত উত্তর দেবেন। অন্যথায়, আপনি গুগল সার্চের মাধ্যমে প্রাপ্ত সর্বশেষ তথ্য বাংলা ভাষায় ব্যবহার করে সাধারণ প্রশ্নের উত্তর দেবেন।";

    public interface GeminiCallback {
        void onResponse(String response);
        void onFailure(String error);
    }

    public void getResponseAsync(final String prompt, final GeminiCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String response = sendRequest(prompt);
                if (response != null && !response.startsWith("Error")) {
                    String parsedText = parseGeminiResponse(response);
                    callback.onResponse(parsedText);
                } else {
                    callback.onFailure(response != null ? response : "API response was null.");
                }
            }
        }).start();
    }

    private String sendRequest(String prompt) {
        if (API_KEY.equals("YOUR_GEMINI_API_KEY_HERE") || API_KEY.isEmpty()) {
            return "Error: অনুগ্রহ করে J.java ফাইলে আপনার API কী প্রবেশ করান।";
        }

        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            // JSON পেলোড তৈরি করা
            JSONObject payload = new JSONObject();

            // 1. System Instruction যোগ করা (কনটেক্সচুয়াল জ্ঞান ইনজেক্ট করা)
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            JSONObject systemPart = new JSONObject();
            systemPart.put("text", SYSTEM_INSTRUCTION);
            systemParts.put(systemPart);
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            // 2. Contents (ব্যবহারকারীর প্রম্পট)
            JSONArray contents = new JSONArray();
            JSONObject part = new JSONObject();
            part.put("text", prompt);
            JSONObject userContent = new JSONObject();
            userContent.put("role", "user");
            userContent.put("parts", new JSONArray().put(part));
            contents.put(userContent);
            payload.put("contents", contents);

            // 3. Tools (Google Search Grounding সক্ষম করা)
            JSONArray toolsArray = new JSONArray();
            JSONObject tool = new JSONObject();
            tool.put("google_search", new JSONObject());
            toolsArray.put(tool);
            payload.put("tools", toolsArray);

            // JSON পেলোডটিকে বাইটে রূপান্তর করা
            String jsonInputString = payload.toString();

            // অনুরোধটি পাঠানো
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // সার্ভারের প্রতিক্রিয়া পড়া
            int responseCode = conn.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    return response.toString();
                }
            } else {
                // ত্রুটি প্রতিক্রিয়া পড়া
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.e(TAG, "HTTP Error Code: " + responseCode + ", Response: " + response.toString());
                    return "Error: HTTP " + responseCode + ". সার্ভার থেকে ত্রুটি।";
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "API কল ব্যর্থ হয়েছে", e);
            return "Error: নেটওয়ার্ক বা পার্সিং ব্যর্থ হয়েছে। (" + e.getMessage() + ")";
        }
    }

    // JSON প্রতিক্রিয়া থেকে শুধুমাত্র পাঠ্য অংশটি বের করা
    private String parseGeminiResponse(String jsonResponse) {
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            JSONArray candidates = jsonObject.getJSONArray("candidates");
            if (candidates.length() > 0) {
                JSONObject firstCandidate = candidates.getJSONObject(0);
                JSONObject content = firstCandidate.getJSONObject("content");
                JSONArray parts = content.getJSONArray("parts");
                if (parts.length() > 0) {
                    JSONObject part = parts.getJSONObject(0);
                    if (part.has("text")) {
                        String text = part.getString("text");
                        return text.replaceAll("\\*", ""); // অপ্রয়োজনীয় * সরানো হলো
                    }
                }
            }
            return "দুঃখিত, আমি একটি সঠিক উত্তর তৈরি করতে পারিনি।";
        } catch (Exception e) {
            Log.e(TAG, "JSON পার্সিং ত্রুটি", e);
            return "পার্সিং ত্রুটি: উত্তর পড়তে পারিনি।";
        }
    }
}