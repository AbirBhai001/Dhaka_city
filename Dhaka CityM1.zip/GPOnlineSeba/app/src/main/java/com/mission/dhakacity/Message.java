package com.mission.dhakacity; // আপনার প্যাকেজের নাম ব্যবহার করুন

// বার্তা মডেল: বার্তা টেক্সট এবং প্রেরকের ধরণ (ব্যবহারকারী বা বট) সংরক্ষণ করে
public class Message {
    public static final int SENDER_USER = 0;
    public static final int SENDER_BOT = 1;

    private String text;
    private int sender;

    public Message(String text, int sender) {
        this.text = text;
        this.sender = sender;
    }

    public String getText() {
        return text;
    }

    public int getSender() {
        return sender;
    }
}