package com.mission.dhakacity;

import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.ServiceWorkerWebSettings;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;

public class E extends AppCompatActivity {

    private WebView webView;
    private LinearLayout layRoot, layNonet;
    private LottieAnimationView progressBar, lottieNoNet;
    private RelativeLayout layoutError;
    private Button btnReload;
    private static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android 4.1.1; Galaxy Nexus Build/JRO03C) "
                    + "AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19";
    public static String url = "https://www.example.com"; // আপনার URL এখানে সেট করুন

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        // --- View Initialization ---
        layRoot     = findViewById(R.id.layRoot);
        progressBar = findViewById(R.id.progressBar);
        layNonet    = findViewById(R.id.layNonet);
        // নেটওয়ার্ক-নথিং এনিমেশন (XML-এ id থাকে lottieNoNet)
        lottieNoNet = findViewById(R.id.lottieNoNet);
        layoutError = findViewById(R.id.layoutError);
        btnReload   = findViewById(R.id.btnReload);

        // XML-ভিত্তিক WebView (id: webView1)
        webView     = findViewById(R.id.webView1);

        // --- WebView Settings ---
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString(USER_AGENT);
        settings.setLoadsImagesAutomatically(true);
        settings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // Optional: Service Worker সাপোর্ট (Android N+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            ServiceWorkerController swController = ServiceWorkerController.getInstance();
            swController.setServiceWorkerClient(new ServiceWorkerClient());
            ServiceWorkerWebSettings swSettings = swController.getServiceWorkerWebSettings();
            swSettings.setAllowContentAccess(true);
            swSettings.setAllowFileAccess(true);
            swSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        }

        // --- WebViewClient ও WebChromeClient ---
        webView.setWebViewClient(new WebViewClient() {
            // লোড শুরুতে
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
                layoutError.setVisibility(View.GONE);
            }
            // এরর হ্যান্ডলিং
            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                layoutError.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            // প্রগ্রেস আপডেট
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                if (newProgress == 100) {
                    progressBar.setVisibility(View.GONE);
                    webView.setVisibility(View.VISIBLE);
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                }
            }
            // ভিডিও ফূলস্ক্রিন সাপোর্ট (ঐচ্ছিক)
            private View mCustomView;
            private WebChromeClient.CustomViewCallback mCustomViewCallback;
            private int mOriginalOrientation;
            private int mOriginalSystemUiVisibility;
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mOriginalSystemUiVisibility = getWindow().getDecorView().getSystemUiVisibility();
                mOriginalOrientation = getRequestedOrientation();
                mCustomViewCallback = callback;
                ((RelativeLayout) getWindow().getDecorView()).addView(mCustomView,
                        new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT,
                                RelativeLayout.LayoutParams.MATCH_PARENT));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
            @Override
            public void onHideCustomView() {
                ((RelativeLayout) getWindow().getDecorView()).removeView(mCustomView);
                mCustomView = null;
                getWindow().getDecorView().setSystemUiVisibility(mOriginalSystemUiVisibility);
                setRequestedOrientation(mOriginalOrientation);
                if (mCustomViewCallback != null) {
                    mCustomViewCallback.onCustomViewHidden();
                }
            }
        });

        // --- URL লোড ও নেটওয়ার্ক চেক ---
        if (isNetworkAvailable()) {
            webView.loadUrl(url);
            layNonet.setVisibility(View.GONE);
        } else {
            layNonet.setVisibility(View.VISIBLE);
            Toast.makeText(this, "Please connect to the Internet", Toast.LENGTH_SHORT).show();
        }

        // --- Reload Button Listener ---
        btnReload.setOnClickListener(v -> {
            if (isNetworkAvailable()) {
                layoutError.setVisibility(View.GONE);
                layNonet.setVisibility(View.GONE);
                webView.reload();
            } else {
                Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // নেটওয়ার্ক স্টেট চেক মেথড
    private boolean isNetworkAvailable() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm != null && cm.getActiveNetworkInfo() != null
                && cm.getActiveNetworkInfo().isConnected();
    }

    // Optional: ফাইল ডাউনলোড হ্যান্ডলিং (Dialog)
    public void downloadDialog(final String url, final String userAgent,
                               String contentDisposition, String mimetype) {
        final String filename = URLUtil.guessFileName(url, contentDisposition, mimetype);
        new AlertDialog.Builder(this)
                .setTitle("Download")
                .setMessage("Download file: " + filename + "?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                    String cookie = CookieManager.getInstance().getCookie(url);
                    request.addRequestHeader("Cookie", cookie);
                    request.addRequestHeader("User-Agent", userAgent);
                    request.allowScanningByMediaScanner();
                    request.setNotificationVisibility(
                            DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    request.setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS, filename);
                    DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                    dm.enqueue(request);
                    Toast.makeText(this, "Downloading " + filename, Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                .show();
    }

    @Override
    public void onBackPressed() {
        // WebView ব্যাক নেভিগেশন
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
