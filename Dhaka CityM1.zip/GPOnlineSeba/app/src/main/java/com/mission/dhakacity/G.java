package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.ArrayList;
import java.util.HashMap;

public class G extends AppCompatActivity {
    ListView listView;
    HashMap<String,String>hashMap=new HashMap<>();
    ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eseba);

        listView=findViewById(R.id.listView);


        //Create E-service List********************************
        creatList(R.drawable.daraz_image,"Daraz Online Sopping");
        creatList(R.drawable.education_cover,"Education Board Result (WEB Based)");
        creatList(R.drawable.passport_cover,"Welcome to Bangladesh e-Passport Portal");
        creatList(R.drawable.jonmo_abedon,"নতুন জন্মনিবন্ধন এর জন্য আবেদন");
        creatList(R.drawable.jonmo_abedon,"জন্মনিবন্ধন তথ্য অনুসন্ধান করুন");
        creatList(R.drawable.jonmo_abedon,"জন্ম তথ্য সংশোধনের জন্য আবেদন");
        creatList(R.drawable.nidbd_cover,"NID নতুন নিবন্ধনের জন্য আবেদন");
        //*****************************************************************






        MyAdapter myAdapter=new MyAdapter();
        listView.setAdapter(myAdapter);


    }
    //onCreate End>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //***Create List Method***********
    private void creatList(int drawable,String list_title){
        hashMap=new HashMap<>();
        hashMap.put("title",list_title);
        hashMap.put("title_cover",String.valueOf(drawable));
        arrayList.add(hashMap);
    }



    //************************************



    //*****Create MyAdapter**********************
    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.e_service_item,viewGroup,false);

            TextView list_title=myView.findViewById(R.id.list_title);
            ImageView itemCover=myView.findViewById(R.id.itemCover);
            CardView listItem=myView.findViewById(R.id.listItem);

            hashMap=arrayList.get(i);
            String itemTitle=hashMap.get("title");
            String sCover=hashMap.get("title_cover");
            int coverItem=Integer.parseInt(sCover);

            itemCover.setImageResource(coverItem);
            list_title.setText(itemTitle);

            //Animation for ListItem
            YoYo.with(Techniques.ZoomInUp).duration(900).repeat(0).playOn(listItem);


            listItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (list_title.getText().toString().contains("Daraz Online")){
                        E.url="https://www.daraz.com.bd/";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("Education")){
                        E.url="https://eboardresults.com/v2/home";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("e-Passport Portal")){
                        E.url="https://www.epassport.gov.bd/landing";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("নতুন জন্মনিবন্ধন এর জন্য আবেদন")){
                        E.url="https://bdris.gov.bd/br/application";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("জন্মনিবন্ধন তথ্য অনুসন্ধান করুন")){
                        E.url="https://bdris.gov.bd/br/search";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("জন্ম তথ্য সংশোধনের জন্য আবেদন")){
                        E.url="https://bdris.gov.bd/br/correction";
                        startActivity(new Intent(G.this, E.class));
                    }
                    else if (list_title.getText().toString().contains("NID নতুন নিবন্ধনের জন্য আবেদন")){
                        E.url="https://services.nidw.gov.bd/nid-pub/register-account/";
                        startActivity(new Intent(G.this, E.class));
                    }





                }
            });


            return myView;
        }
    }
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


}