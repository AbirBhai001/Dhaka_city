package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import java.util.ArrayList;
import java.util.HashMap;

public class H extends AppCompatActivity {

    //initaliz variable
    TextView pageTitle;
    ListView fireListView;
    //Array
    HashMap<String,String>hashMap=new HashMap<>();
    public static ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>fireseviceList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>pulishList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>polliBidyutList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>helpLineList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>ambulenceList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>collageList=new ArrayList<>();


    public static ArrayList<HashMap<String,String>>rabList=new ArrayList<>();


    public static String TITLE=" ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fire_service);

        //Find variable
        fireListView=findViewById(R.id.fireListView);
        pageTitle=findViewById(R.id.pageTitle);

        pageTitle.setText(""+TITLE);


        //create_fireserviceList**********************
        create_fireList("জরুরী সেবা (জাতীয়)","999");
        create_fireList("ফায়ার সার্ভিস হটলাইন","102");
        create_fireList("ফায়ার সার্ভিস কন্ট্রোল রুম (কেন্দ্রীয়)","02-223355555");
        create_fireList("সিদ্দিকবাজার ফায়ার স্টেশন","01901-020748");
        create_fireList("সদরঘাট ফায়ার স্টেশন","01901-020750");
        create_fireList("পোস্তগোলা ফায়ার স্টেশন","01901-020756");
        create_fireList("লালবাগ ফায়ার স্টেশন","01901-020790");
        create_fireList("খিলগাঁও ফায়ার স্টেশন","01901-020760");
        create_fireList("তেজগাঁও ফায়ার স্টেশন","01901-020758");
        create_fireList("মোহাম্মদপুর ফায়ার স্টেশন","01901-020761");
        create_fireList("মিরপুর ফায়ার স্টেশন","01901-020763");
        create_fireList("কুর্মিটোলা ফায়ার স্টেশন","01901-020767");
        create_fireList("উত্তরা ফায়ার স্টেশন","01901-020782");
        create_fireList("ডেমরা ফায়ার স্টেশন","01901-020777");
        create_fireList("বারিধারা ফায়ার স্টেশন","01901-020780");
        create_fireList("কেরানীগঞ্জ ফায়ার স্টেশন","01901-020810");
        create_fireList("সাভার ফায়ার স্টেশন","01901-020820");
        fireseviceList=new ArrayList<>();
        //********************************************************



        //create_pulishList****************************
        create_pulishList("ওসি মিরপুর মডেল থানা","01713373180");
        create_pulishList("ওসি পল্লবী থানা","01713373181");
        create_pulishList("ওসি শাহ আলী থানা","01713373182");
        create_pulishList("ওসি কাফরুল থানা","01713373183");
        create_pulishList("ওসি তেজগাঁও থানা","01713373191");
        create_pulishList("ওসি ধানমন্ডি থানা","01713373204");
        create_pulishList("ওসি গুলশান থানা","01713373220");
        create_pulishList("ওসি ভাটারা থানা","01713373226");
        create_pulishList("ওসি রামপুরা থানা","01713373240");
        create_pulishList("ওসি মতিঝিল থানা","01713373250");
        create_pulishList("ওসি যাত্রাবাড়ী থানা","01713373265");
        create_pulishList("ওসি কোতোয়ালি থানা","01713373278");
        create_pulishList("ওসি উত্তরা পশ্চিম থানা","01713373300");
        pulishList=new ArrayList<>();
        //*********************************************************



        //create_pulishList****************************
        create_polliBidyutList("REB কেন্দ্রীয় কল সেন্টার (দেশব্যাপী)","16899");
        create_polliBidyutList("ডিপিবিএস-১ সদর দপ্তর অভিযোগ কেন্দ্র","01769401064");
        create_polliBidyutList("ডিপিবিএস-১ আশুলিয়া জোনাল অফিস","01769401070");
        create_polliBidyutList("ডিপিবিএস-১ বিশমাইল অভিযোগ কেন্দ্র","01769401065");
        create_polliBidyutList("ডিপিবিএস-১ ইউনিক অভিযোগ কেন্দ্র","01769407540");
        create_polliBidyutList("ডিপিবিএস-১ ঘোড়াপীর অভিযোগ কেন্দ্র","01769407541");
        create_polliBidyutList("ডিপিবিএস-১ ডেইরি ফার্ম অভিযোগ কেন্দ্র","01769407542");
        create_polliBidyutList("ডিপিবিএস-১ বিরুলিয়া অভিযোগ কেন্দ্র","01769401954");
        create_polliBidyutList("ডিপিবিএস-১ দূর্গাপুর অভিযোগ কেন্দ্র","01769401765");
        create_polliBidyutList("ডিপিবিএস-১ জামগড়া জোনাল অফিস","01769401071");
        create_polliBidyutList("ডিপিবিএস-৩ হটলাইন (২৪ ঘন্টা)","01769404003");
        create_polliBidyutList("ডিপিবিএস-৩ সদর দপ্তর অভিযোগ কেন্দ্র","01769401075");
        create_polliBidyutList("ডিপিবিএস-৩ আমিন বাজার অভিযোগ কেন্দ্র","01769401072");
        create_polliBidyutList("ডিপিবিএস-৩ ট্যানারী অভিযোগ কেন্দ্র","01769401955");
        create_polliBidyutList("ডিপিবিএস-৩ ফুলবাড়ীয়া অভিযোগ কেন্দ্র","01769401078");
        create_polliBidyutList("ডিপিবিএস-৩ শিমুলতলা অভিযোগ কেন্দ্র","01769401956");
        create_polliBidyutList("ডিপিবিএস-৩ রাজাশন অভিযোগ কেন্দ্র","01769401077");
        create_polliBidyutList("ডিপিবিএস-৩ নয়ারহাট অভিযোগ কেন্দ্র","01769401986");
        create_polliBidyutList("ডিপিবিএস-৩ ধামরাই অভিযোগ কেন্দ্র","01769401079");
        create_polliBidyutList("ডিপিবিএস-৩ কুশুরা অভিযোগ কেন্দ্র","01769401083");
        create_polliBidyutList("ডিপিবিএস-৪ হটলাইন","01769404080");
        create_polliBidyutList("ডিপিবিএস-৪ হাসনাবাদ অভিযোগ কেন্দ্র","01769401109");
        create_polliBidyutList("ডিপিবিএস-৪ কোন্ডা অভিযোগ কেন্দ্র","01769401112");
        create_polliBidyutList("ডিপিবিএস-৪ আলুকান্দা অভিযোগ কেন্দ্র","01769407925");
        polliBidyutList=new ArrayList<>();
        //*********************************************************


        //create_HelpLineList****************************
        creatHelpLine("জাতীয় জরুরী সেবা","999");
        creatHelpLine("জরুরী হট লাইন","16575");
        creatHelpLine("নারী ও শিশু নির্যাতন প্রতিরোধ","109");
        creatHelpLine("শিশুর সহয়তায় ফোন","1098");
        creatHelpLine("কৃষি বিষয়ক পরামর্শ","16123");
        creatHelpLine("জাতীয় তথ্য ও সেবা","333");
        creatHelpLine("জাতীয় পরিচয়পত্র সেবা","105");
        creatHelpLine("বাংলাদেশ মুক্তিযোদ্ধা কল্যায়ন ট্রাস্ট","16171");
        creatHelpLine("সরকারি আইনি সেবা","16430");
        creatHelpLine("দুদক","106");
        creatHelpLine("দুর্যোগের আগাম বার্তা","1090");
        creatHelpLine("ভুমি সেবা","16122");
        helpLineList=new ArrayList<>();
        //*********************************************************


        //create_HelpLineList****************************

        createAmbulenceList(" আল মামুন এ্যাম্বুলেন্স সার্ভিস","01712462521");
        createAmbulenceList("জহির এ্যাম্বুলেন্স সার্ভিস","01719966119");
        createAmbulenceList("হাসিব এ্যাম্বুলেন্স সার্ভিস","01714738720");
        createAmbulenceList("সিকদার এ্যাম্বুলেন্স সার্ভিস","01713260042");
        createAmbulenceList("মুন্সি এ্যাম্বুলেন্স সার্ভিস","01717770852");
        createAmbulenceList("আনজুমান এ্যাম্বুলেন্স সার্ভিস","01627669222");
        createAmbulenceList("অনলাইন এ্যাম্বুলেন্স সার্ভিস","01627669222");
        createAmbulenceList("২৪ ঘণ্টা এ্যাম্বুলেন্স সার্ভিস","01911125156");
        ambulenceList=new ArrayList<>();
        //*********************************************************




        //create_pulishList****************************
        createCollageList("নটরডেম কলেজ","02-9330177");
        createCollageList("ভিকারুননিসা নূন স্কুল অ্যান্ড কলেজ","02-9110493");
        createCollageList("আদমজী ক্যান্টনমেন্ট কলেজ","02-8872446");
        createCollageList("ঢাকা কলেজ","02-8618359");
        createCollageList("রাজউক উত্তরা মডেল কলেজ","02-48953360");
        createCollageList("ঢাকা কমার্স কলেজ","9023338");
        createCollageList("ঢাকা হিলফুল-ফুজুল টেকনিক্যাল অ্যান্ড বিএম কলেজ","01751815632");
        createCollageList("উদয়ন উচ্চ মাধ্যমিক বিদ্যালয় (সাবেক: ঢাকা উদায়ন লাইব্রি)","02-9662121");
        createCollageList("ঢাকা বিশ্ববিদ্যালয়","02-9661900");
        createCollageList("জাহাঙ্গীরনগর বিশ্ববিদ্যালয় (সাভার)","02-7791045");
        createCollageList("ইডেন মহিলা কলেজ","01712197416");
        createCollageList("সরকারি বাঙলা কলেজ","01711978103");
        createCollageList("তেজগাঁও কলেজ","02-55029415");
        createCollageList("মাইলস্টোন কলেজ","01711172600");
        createCollageList("হলিক্রস কলেজ, ঢাকা","02-9614488");
        createCollageList("কবি নজরুল সরকারি কলেজ","02-7117562");
        createCollageList("নর্থ সাউথ ইউনিভার্সিটি","02-55668200");
        createCollageList("মিরপুর ক্যান্টনমেন্ট পাবলিক স্কুল ও কলেজ","02-9014381");
        createCollageList("বীরশ্রেষ্ঠ মুন্সী আব্দুর রউফ পাবলিক কলেজ","02-58814755");
        createCollageList("ঢাকা সিটি কলেজ","02-9665471");
        collageList=new ArrayList<>();
        //*********************************************************

        //create_pulishList****************************
        createrablist("র‌্যাব ঢাকা","01777710811");
        createrablist("র‌্যাব ফরিদপুর","01777710822");
        createrablist("র‌্যাব মাদারিপুর","01777710833");
        createrablist("র‌্যাব বরিশাল","01777710855");
        createrablist("সদর দপ্তর বরিশাল","017777108803");
        createrablist("সদর দপ্তর বরিশাল","043171783");
        rabList=new ArrayList<>();
        //*********************************************************






        MyAdapter myAdapter=new MyAdapter();
        fireListView.setAdapter(myAdapter);


    }//onCreate End>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>






    //Create FireList Method*******************
    private void create_fireList(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        fireseviceList.add(hashMap);
    }


    //Create PulishList Method*******************
    private void create_pulishList(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        pulishList.add(hashMap);
    }


    //Create PolliBidyut Method*******************
    private void create_polliBidyutList(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        polliBidyutList.add(hashMap);
    }


    //Create HelpLine Method*******************
    private void creatHelpLine(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        helpLineList.add(hashMap);
    }


    //Create Ambulence Method*******************
    private void createAmbulenceList(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        ambulenceList.add(hashMap);
    }



    //Create FireList Method*******************
    private void createCollageList(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        collageList.add(hashMap);
    }

    //Create FireList Method*******************
    private void createrablist(String stetation_name,String stetation_numbar){
        hashMap=new HashMap<>();
        hashMap.put("name",stetation_name);
        hashMap.put("numbar",stetation_numbar);
        rabList.add(hashMap);
    }







    //Creat MyAdapter******************************
    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {

            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.fireservice_list,viewGroup,false);

            ShimmerTextView stName=myView.findViewById(R.id.stetationName);
            ShimmerTextView stNumbar=myView.findViewById(R.id.stetationNumbar);
            LottieAnimationView call_lottie=myView.findViewById(R.id.call_lottie);
            CardView cardView=myView.findViewById(R.id.cardView);

            Shimmer shimmer=new Shimmer();
            //shimmer.start(stName);
            //shimmer.start(stNumbar);

            //Animation for CardView
            YoYo.with(Techniques.ZoomInUp).duration(900).repeat(0).playOn(cardView);


            //get String from ArrayList
            hashMap=arrayList.get(position);
            String sName=hashMap.get("name");
            String sNumbar=hashMap.get("numbar");

            stName.setText(""+sName);
            stNumbar.setText(""+sNumbar);

            call_lottie.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent call=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+sNumbar));
                    startActivity(call);

                }
            });



            return myView;
        }
    }

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



}