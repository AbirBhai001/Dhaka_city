package com.mission.dhakacity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.romainpiel.shimmer.Shimmer;
import com.romainpiel.shimmer.ShimmerTextView;

import java.util.ArrayList;
import java.util.HashMap;

public class D extends AppCompatActivity {

    //Initializ Variable
    TextView pageTitle;
    ListView bloodDonnarListView;

    //Initializ Array
    HashMap<String,String>hashMap=new HashMap<>();
    public static ArrayList<HashMap<String,String>>arrayList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>lowearList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>sinour_secchasebi=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>sadarList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>muksudpurList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>kasiyaniList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>tungiparaList=new ArrayList<>();
    public static ArrayList<HashMap<String,String>>kotaliparaList=new ArrayList<>();

    public static String TITEL="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blood_donnar);

        //Find variable
        bloodDonnarListView=findViewById(R.id.bloodDonnarListView);
        pageTitle=findViewById(R.id.pageTitle);

        pageTitle.setText(TITEL);

        //Creat Lowayer List***************************************************
        // এখানে আমি সবগুলোতে ডিফল্ট হিসেবে "active" দিয়েছি, আপনি চাইলে পরিবর্তন করতে পারেন
        createLowyer_list("এ.বি.এম. শহিদুল আলম","(দেওয়ানী)"," ০১৭১৫৮৫২০০০", "active");
        createLowyer_list("আবুল হোসেন","(দেওয়ানী)","০১৭২৭৫৮২৫৭৭", "active");
        createLowyer_list("আলাউদ্দিন","(দেওয়ানী)","০১৭৩১৪০৮৪২৩", "active");
        createLowyer_list("ননী গোপাল সুকুল","(দেওয়ানী)"," ০১৭৫২৮৮১৪৮২", "active");
        createLowyer_list("সচ্চিদানন্দ রায় চৌধুরী","(দেওয়ানী)","০১৭১৭৬৫৩০৭৪", "active");
        createLowyer_list("আঃ হাই খন্দকার","(দেওয়ানী)","০১৭১৮৬৬২০০৬", "active");
        createLowyer_list("মিসেস বিভা রানী সাহা","(দেওয়ানী)","০১৭৯০১৫৫৬৫২", "active");
        createLowyer_list("কাজী আঃ রশিদ","(দেওয়ানী)","০১৯১৫১১২৯০৬", "active");
        createLowyer_list("মিসেস আমেনা বেগম","(দেওয়ানী)","০১৭১২২১৫১৬৪", "active");
        createLowyer_list("আবুল কালাম আজাদ (২)","(দেওয়ানী)","০১৭১২২১৫১৬৮", "active");
        createLowyer_list("নিজাম উদ্দিন আহম্মেদ","(দেওয়ানী)","০১৭১৬৪২৩৮৪৪", "active");
        createLowyer_list("মোঃ আঃ খালেক (৭)","(দেওয়ানী)","০১৭১৮০২৬৩৬৪", "active");
        createLowyer_list("আনছার আলী","(দেওয়ানী)","০১৭১৬০২৭৯০৭", "active");
        createLowyer_list("আলহাজ্জ্ব মোঃ মিলন চৌধুরী","(দেওয়ানী)","০১৭১৬৯৬৬১৭৯", "active");

        createLowyer_list( "মোঃ মাহমুদুল হাসান","(ফৌজদারি)","০১৭১৯৭১৮৮৭৫", "active");
        createLowyer_list( "জালাল উদ্দিন আহম্মেদ (১)","(ফৌজদারি)","০১১৯১৩০৮৯৩৭", "active");
        createLowyer_list("আবুল কাশেম","(ফৌজদারি)","০১৭১৪২৩৪০৭৩", "active");
        createLowyer_list("রুহুল আমিন (১)","(ফৌজদারি)","০১৭১৭৪০১৫৩২", "active");
        createLowyer_list("এ.কে.এম. হুমায়ন কবির(১)","(ফৌজদারি)","০১৮২৪৪৯৮৮৯৬", "active");
        createLowyer_list("মোঃ মোশাররফ হোসেন","(ফৌজদারি)","০১৭১২২৭৭৩২১", "active");
        createLowyer_list("এ.কে.এম. আজিজুল হক","(ফৌজদারি)","০১৭১২৭৫৮০৮১", "active");
        createLowyer_list("মোঃ ওয়াহিদ সরোয়ার","(ফৌজদারি)","০১৮১৯৯৩১৮১২", "active");
        createLowyer_list("মোঃ হারুন অর রশিদ (২)","(ফৌজদারি)","০১৭১৬০৪২৭৪৮", "active");
        createLowyer_list("কে.বি.এম আরিফুল হক","(ফৌজদারি)","০১৭১২২৮২৮৬০", "active");
        createLowyer_list("মোঃ নজরুল ইসলাম (১)","(ফৌজদারি)","০১৭১২৭৫৯২২৮", "active");
        createLowyer_list("আঃ হালিম বিশ্বাস","(ফৌজদারি)","০১৭১৫৪২২৭৪৫", "active");
        createLowyer_list("আঃ সালাম (২)","(ফৌজদারি)","০১৭২৪১০৯৪৭২", "active");
        createLowyer_list("মোমোঃ মজিবুর রহমান (৭)","(ফৌজদারি)","০১৭১৫০৩৬৫০৯", "active");
        createLowyer_list("মোঃ আবু জাফর খান","(ফৌজদারি)","01725625974", "active");

        createLowyer_list("আদালত, মির্জাগঞ্জ, চৌকি।"," ","", ""); // Title, no status
        createLowyer_list("চিত্ত রঞ্জন দাস","(আদালত, মিজাগঞ্জ, চৌকি)","০১৭১৭৪৭৪০৩০", "active");
        createLowyer_list("মোঃ মজিবুর রহমান (২)","(আদালত, মিজাগঞ্জ, চৌকি)","০১৭১৭২১১২৩১", "active");
        createLowyer_list("মিঃ ইউসুফ আলী","(আদালত, মিজাগঞ্জ, চৌকি)","০১৭১৬৫৮৩২৮৯", "active");
        createLowyer_list("মোঃ ইউনুছ (৫)","(আদালত, মিজাগঞ্জ, চৌকি)","০১৭১৮৫৫৫৬৯৮", "active");
        createLowyer_list("মোঃ তারিকুল ইসলাম","(আদালত, মিজাগঞ্জ, চৌকি)","০১৭২৪১৮২১৪০", "active");

        createLowyer_list("আদালত, গলাচিপা, চৌকি।","  ","", "");
        createLowyer_list("আঃ খালেক (৫)","(আদালত, গলাচিপা, চৌকি।)","০১৭৪৬১৮৩৮৩১", "active");
        createLowyer_list("মোঃ মিজানুর রহমান (১)","(আদালত, গলাচিপা, চৌকি।)","০১৭১৪৬৬৮৯২৪", "active");
        createLowyer_list("এ. কে. এম. আজাদ (১)","(আদালত, গলাচিপা, চৌকি।)","০১৭১৭১৮৫৫৬৪", "active");
        createLowyer_list("রুহুল আমিন","(আদালত, গলাচিপা, চৌকি।)","০১৭১২৯৪৯১৮৪", "active");

        createLowyer_list("আদালত, কলাপাড়া, চৌকি।","  ","", "");
        createLowyer_list("জ্ঞানেন্দ্র চন্দ্র মন্ডল","(আদালত, কলাপাড়া, চৌকি।)","০১৭১২৪০৪০৪৯", "active");
        createLowyer_list("মজিবুর রহমান (৩)","(আদালত, কলাপাড়া, চৌকি।)","০১৭১২৯৩৭৭৪৫", "active");
        createLowyer_list("মোঃ নাসির উদ্দিন","(আদালত, কলাপাড়া, চৌকি।)","০১৭১২৭৮১২৬১", "active");
        createLowyer_list("জাফরখান","(আদালত, কলাপাড়া, চৌকি।)","01725625974", "active");

        lowearList=new ArrayList<>();
        //******************************************************************************

        //Create Sador_list *************************************Boold list
        // এখানে উদাহরণ হিসেবে কিছু inactive দেখানো হয়েছে
        createSadar_list("মো: ইসমাইল হোসেন আরিফ(AB Positive)","(স্বেচ্ছাসেবী)"," 01746183608", "active");
        createSadar_list("মো: ইলিয়াচ আকন(A Positive)","(স্বেচ্ছাসেবী)"," 01626512696", "active");
        createSadar_list("মো: রাজিব খন্দকার(A Positive)","(স্বেচ্ছাসেবী)"," 01738977317", "inactive"); // Example inactive
        createSadar_list("মো: আসাদুল(A Positive)","(স্বেচ্ছাসেবী)","01303698974", "active");
        createSadar_list("তাজুল ইসলাম(AB positive)","(স্বেচ্ছাসেবী)","01725462838", "inactive");
        createSadar_list("মোঃখায়রুল ইসলাম(A Positive)","(স্বেচ্ছাসেবী)"," 01571-758754", "active");
        createSadar_list("ওমিতিব দাস(O Positive)","(স্বেচ্ছাসেবী)","01792053571", "inactive");
        createSadar_list("মোঃ জাহিদ হাসান(B Negative)","(স্বেচ্ছাসেবী)","01675696955", "active");
        createSadar_list("মোঃ আল মামুন মৃধা(B Positive)","(স্বেচ্ছাসেবী)","01713674153", "active");
        createSadar_list("রবিউর রাবি(B Positive)","(স্বেচ্ছাসেবী)","01716822449", "inactive");
        createSadar_list("হাফিজুর রহমান(A Positive)","(স্বেচ্ছাসেবী)","01957588260", "active");
        createSadar_list("শুভ(O Positive)","(স্বেচ্ছাসেবী)","01795479126", "active");
        createSadar_list("রিদয় দাষ(O Positive)","(স্বেচ্ছাসেবী)","01791801484", "inactive");
        createSadar_list("ইসমিত জাহান(B Positive)","(স্বেচ্ছাসেবী)"," 01795713651", "active");
        createSadar_list("মো: সাইফুল ইসলাম(B Positive)","(স্বেচ্ছাসেবী)","01743412929", "active");
        createSadar_list("মানজুরুল ইসলাম(AB positive)","(স্বেচ্ছাসেবী)","01731357593", "inactive");
        createSadar_list("মামুন হোসেন(B Positive)","(স্বেচ্ছাসেবী)","01716515351", "active");
        createSadar_list("মোঃ রাসেল ইকবাল(A Positive)","(স্বেচ্ছাসেবী)","01724661122", "active");
        createSadar_list("আল মামুন(A Positive)","(স্বেচ্ছাসেবী)"," 01712232621", "active");
        createSadar_list("প্রদীপ কুমার(AB positive)","(স্বেচ্ছাসেবী)","01758276659", "inactive");
        createSadar_list("মোঃনজরুল ইসলাম(A positive)","(স্বেচ্ছাসেবী)","01321149449", "active");
        createSadar_list("সঞ্চয় কর্মকার(O Positive)","(স্বেচ্ছাসেবী)","01717970118", "active");
        createSadar_list("রুহুল আমিন(O Positive)","(স্বেচ্ছাসেবী)","01719364185", "active");
        createSadar_list("মোঃতাজকিন(AB positive)","(স্বেচ্ছাসেবী)","01759434286", "active");

        sadarList=new ArrayList<>();
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>=====================

        //Create Muksudpur_list*******************************************
        createMuksudpur_list("মো: রাহাত(O Positive)","(স্বেচ্ছাসেবী)","01722223859", "active");
        createMuksudpur_list("নিবদিতা দেবনাথ(O Positive)","(স্বেচ্ছাসেবী)","01777049993", "inactive");
        createMuksudpur_list("উমর হোসেন(AB positive)","(স্বেচ্ছাসেবী)"," 01792053725", "active");
        createMuksudpur_list("তানভীর ইসলাম(AB positive)","(স্বেচ্ছাসেবী)","01948636996", "active");
        createMuksudpur_list("নাজমুল হাসান(B Positive)","(স্বেচ্ছাসেবী)","01825978018", "inactive");
        muksudpurList=new ArrayList<>();
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        //Create Kasiyani_list*****************************************************
        createKasiyani_list("সাইফুর রহমান(O Positive)","(স্বেচ্ছাসেবী)"," 01710504172", "active");
        createKasiyani_list("সামিম তুশার(A Positive)","(স্বেচ্ছাসেবী)","01609547691", "active");
        createKasiyani_list("তরিকুল ইসলাম তুহিন(O Positive)","(স্বেচ্ছাসেবী)","01744533103", "inactive");
        createKasiyani_list("মোঃ পারভেজ(B Positive)","(স্বেচ্ছাসেবী)","01710382304", "active");
        createKasiyani_list("সবুজ (A Positive)","(স্বেচ্ছাসেবী)","01778665395", "active");
        createKasiyani_list("খোকন সরকার(O Positive)","(স্বেচ্ছাসেবী)","01723474497", "inactive");
        createKasiyani_list("লুৎফর রহমান(A Positive)","(স্বেচ্ছাসেবী)","01870777404", "active");
        createKasiyani_list("জাকারিয়া(O Negative)","(স্বেচ্ছাসেবী)","01722455141", "inactive");
        createKasiyani_list("রাকিবুল হাসান তানজিল(A Positive)",".."," 01733219300", "active");
        createKasiyani_list("সবুজ(A Negative)","(....)","01714151131", "active");
        createKasiyani_list("সাগর(AB positive)","(...)","01643708438", "active");
        createKasiyani_list("রেজাউল(O Positive)","(....)","01710130415", "active");
        kasiyaniList=new ArrayList<>();
        //>>>>>>>>>>>>>>>>>>>>>>>>>

        //Create Tungipara_list*********************************************
        createTungipara_list("মিজানুর রহমান (A Positive)","(স্বেচ্ছাসেবী)","01760896979", "active");
        createTungipara_list("মোঃশিহাবুর রহমান(O Positive)","(স্বেচ্ছাসেবী)","01627424085", "active");
        createTungipara_list("মো:সোহাগ(AB positive)","(স্বেচ্ছাসেবী)","01795712859", "active");
        createTungipara_list("সফিকুল ইসলাম(B Positive)","(স্বেচ্ছাসেবী)","01710024348", "inactive");
        createTungipara_list("মোঃমেহেদীহাসান(A Positive)","(স্বেচ্ছাসেবী)","01735653635", "active");
        createTungipara_list("জুবায়ের(AB positive)","(স্বেচ্ছাসেবী)","01790059606", "active");
        createTungipara_list("উজ্জাল মিয়া(O Positive)","(স্বেচ্ছাসেবী)","01936404076", "active");
        createTungipara_list("মোঃ নাবিল(B Positive)","(স্বেচ্ছাসেবী)","01728415829", "active");
        createTungipara_list("মোঃ ইমরান(A Positive)","(স্বেচ্ছাসেবী)","01533674937", "inactive");
        createTungipara_list("রাকিবুল ইসলাম(B Positive)","(স্বেচ্ছাসেবী)","01778761661", "active");
        createTungipara_list("আজম(B Positive)","(স্বেচ্ছাসেবী)"," 01712291305", "active");
        createTungipara_list("আজম(B Positive)","(স্বেচ্ছাসেবী)"," 01712291305", "active");
        createTungipara_list("আজম(B Positive)","(স্বেচ্ছাসেবী)"," 01712291305", "active");
        tungiparaList=new ArrayList<>();
        //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        //Create Kotalipara_list****************************************
        createKotalipara_list("জমোঃ আব্দুর রহমান খান(A Positive)","(স্বেচ্ছাসেবী)","01723113110", "active");
        createKotalipara_list("রাজিব খান(AB positive)","(স্বেচ্ছাসেবী)"," 01753794435", "active");
        createKotalipara_list("মাসুদ আলম(O Positive)","(স্বেচ্ছাসেবী)","01724520896", "inactive");
        createKotalipara_list("শ্রী মিঠু চন্দ্র(B Positive)","(স্বেচ্ছাসেবী)","01980694431", "active");
        createKotalipara_list("মোঃ সাইফুর রহমান(B Positive)","(স্বেচ্ছাসেবী)","01716720315", "active");
        createKotalipara_list("তাওহিদ তুহিন(A Positive)","(স্বেচ্ছাসেবী)","01733599887", "active");
        createKotalipara_list("বিউটি বেগম(B Positive)","(স্বেচ্ছাসেবী)","01720804659", "inactive");
        createKotalipara_list("সানজিব(A Positive)","(স্বেচ্ছাসেবী)","01781336928", "active");
        createKotalipara_list("মেহেদী হাসান(A Positive)","(স্বেচ্ছাসেবী)","01746963656", "active");
        kotaliparaList=new ArrayList<>();
        //*********************************************************

        //Create Sinour_secchasebi_list***********************************1111
        createSenior_secchasebiList("মো: ইসমাইল হোসেন আরিফ(AB Positive)","(স্বেচ্ছাসেবী)","01746183608", "active");
        createSenior_secchasebiList("মো: ইলিয়াচ আকন(A Positive)","(স্বেচ্ছাসেবী)","01626512696", "active");
        createSenior_secchasebiList("মো: ইমরান হোসেন","(স্বেচ্ছাসেবী)","01610795305", "inactive");
        createSenior_secchasebiList("মো: কামাল ","(স্বেচ্ছাসেবী)","01739008742", "active");
        createSenior_secchasebiList("সবুজ ইসলাম শুভ","(স্বেচ্ছাসেবী)","01911115481", "active");
        createSenior_secchasebiList("মোঃখায়রুল ইসলাম(A Positive)","(স্বেচ্ছাসেবী)"," 01571-758754", "active");
        createSenior_secchasebiList("ওমিতিব দাস(O Positive)","(স্বেচ্ছাসেবী)","01792053571", "inactive");
        createSenior_secchasebiList("মোঃ জাহিদ হাসান(B Negative)","(স্বেচ্ছাসেবী)","01675696955", "active");
        createSenior_secchasebiList("মোঃ আল মামুন মৃধা(B Positive)","(স্বেচ্ছাসেবী)","01713674153", "active");
        createSenior_secchasebiList("মো: মোসারেফ হোসেন","(স্বেচ্ছাসেবী)","00000", "active");
        createSenior_secchasebiList("ইসমাইল হোসোন","(স্বেচ্ছাসেবী)","00000", "active");
        createSenior_secchasebiList("রুদ্র মাহমুদ রাসেল","(স্বেচ্ছাসেবী)","000000", "active");
        createSenior_secchasebiList("সুজন সিকদার","(স্বেচ্ছাসেবী)","0000000", "inactive");
        createSenior_secchasebiList("এম আরমান খান জয়","(স্বেচ্ছাসেবী)","0000000", "active");
        sinour_secchasebi=new ArrayList<>();
        //*********************************************************

        MyAdapter myAdapter=new MyAdapter();
        bloodDonnarListView.setAdapter(myAdapter);

    }
    //onCreate End Here>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //Create Lowyer_list Method Updated**********************************
    private void createLowyer_list(String itemName, String tvAdress, String contactNumbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",itemName);
        hashMap.put("catagory",tvAdress);
        hashMap.put("numbar",contactNumbar);
        hashMap.put("status", status); // Status added
        lowearList.add(hashMap);
    }

    //Create SadarList Method Updated****************************
    private void createSadar_list(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        sadarList.add(hashMap);
    }

    //Create Muksudpur_list Method Updated****************************
    private void createMuksudpur_list(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        muksudpurList.add(hashMap);
    }

    //Create Kasiyani_list Method Updated****************************
    private void createKasiyani_list(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        kasiyaniList.add(hashMap);
    }

    //Create Tungipara_list Method Updated****************************
    private void createTungipara_list(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        tungiparaList.add(hashMap);
    }

    //Create Kotalipara_list Method Updated****************************
    private void createKotalipara_list(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        kotaliparaList.add(hashMap);
    }

    //Create sinour_list Method Updated****************************
    private void createSenior_secchasebiList(String name, String catagory, String numbar, String status){
        hashMap=new HashMap<>();
        hashMap.put("name",name);
        hashMap.put("catagory",catagory);
        hashMap.put("numbar",numbar);
        hashMap.put("status", status); // Status added
        sinour_secchasebi.add(hashMap);
    }

    //Create MyAdapter*******************************
    private class MyAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater= (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView=inflater.inflate(R.layout.blood_donnar_list,parent,false);

            // Finding Views
            LottieAnimationView call_lottie = myView.findViewById(R.id.call_lottie);
            ShimmerTextView itemName = myView.findViewById(R.id.itemName);
            ShimmerTextView tvAdress = myView.findViewById(R.id.tvAdress);
            ShimmerTextView contactNumbar = myView.findViewById(R.id.contactNumbar);
            ShimmerTextView message = myView.findViewById(R.id.message);
            CardView careView = myView.findViewById(R.id.careView);

            // New TextView for Status (Make sure ID tvStatus exists in XML)
            TextView tvStatus = myView.findViewById(R.id.tvStatus);

            //shimmer effect
            Shimmer shimmer=new Shimmer();
            shimmer.start(message);
            //>>>>>>>>>>>>>>>>>>>>>>>>>>

            //Get String from arrayList
            hashMap = arrayList.get(position);
            String sItemName = hashMap.get("name");
            String sTvAdress = hashMap.get("catagory");
            String sContactNumbar = hashMap.get("numbar");
            String sStatus = hashMap.get("status"); // Getting status

            itemName.setText(sItemName);
            tvAdress.setText(sTvAdress);
            contactNumbar.setText(sContactNumbar);

            // Active/Inactive Logic
            if (sStatus != null && sStatus.equalsIgnoreCase("active")) {
                tvStatus.setText("Active");
                tvStatus.setTextColor(Color.parseColor("#4CAF50")); // Green
                tvStatus.setVisibility(View.VISIBLE);
            } else if (sStatus != null && sStatus.equalsIgnoreCase("inactive")) {
                tvStatus.setText("Inactive");
                tvStatus.setTextColor(Color.parseColor("#FFEB3B")); // Red
                tvStatus.setVisibility(View.VISIBLE);
            } else {
                // If status is empty (like titles), hide the text
                tvStatus.setVisibility(View.GONE);
            }

            //Animation for CardView
            YoYo.with(Techniques.ZoomInUp).duration(900).repeat(0).playOn(careView);

            call_lottie.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent call=new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+sContactNumbar));
                    startActivity(call);
                }
            });

            message.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent sms =new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:"+contactNumbar.getText().toString()));
                    startActivity(sms);
                }
            });

            return myView;
        }
    }
}